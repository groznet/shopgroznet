<?php
/**
 * Site footer.
 *
 * Shared by every template, including all WooCommerce pages.
 *
 * @package Shop_GrozNet
 */

defined( 'ABSPATH' ) || exit;
?>
	</div><!-- #content -->

	<footer id="colophon"
		class="site-footer bg-neutral-50 dark:bg-neutral-950 text-neutral-500 dark:text-neutral-400 text-[13px] pt-16 pb-8 border-t border-neutral-200/50 dark:border-neutral-900 transition-colors duration-300">

		<div class="<?php sgz_ui_class( 'container' ); ?>">

			<?php if ( is_active_sidebar( 'footer-widgets' ) ) : ?>
				<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 pb-12">
					<?php dynamic_sidebar( 'footer-widgets' ); ?>
				</div>
			<?php endif; ?>

			<div class="flex flex-col md:flex-row md:items-center md:justify-between gap-6 pt-8 border-t border-neutral-200/60 dark:border-neutral-900">

				<div class="space-y-2">
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"
						class="text-lg font-serif font-bold text-neutral-900 dark:text-white tracking-tight hover:text-brand-600 dark:hover:text-brand-400 transition-colors">
						<?php bloginfo( 'name' ); ?>
					</a>
					<p class="leading-relaxed">
						<?php
						printf(
							/* translators: 1: current year, 2: site name. */
							esc_html__( '&copy; %1$s %2$s. All rights reserved.', 'shop-groznet' ),
							esc_html( gmdate( 'Y' ) ),
							esc_html( get_bloginfo( 'name' ) )
						);
						?>
					</p>
				</div>

				<?php if ( has_nav_menu( 'footer' ) ) : ?>
					<nav class="footer-navigation" aria-label="<?php esc_attr_e( 'Footer menu', 'shop-groznet' ); ?>">
						<?php
						wp_nav_menu(
							array(
								'theme_location' => 'footer',
								'container'      => false,
								'menu_class'     => 'flex flex-wrap items-center gap-x-6 gap-y-2',
								'depth'          => 1,
								'fallback_cb'    => false,
							)
						);
						?>
					</nav>
				<?php endif; ?>

			</div>
		</div>
	</footer>

</div><!-- #page -->

<?php wp_footer(); ?>
</body>
</html>
