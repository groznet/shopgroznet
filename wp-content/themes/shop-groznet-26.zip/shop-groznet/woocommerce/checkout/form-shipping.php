<?php
/**
 * Checkout shipping fields and order notes.
 *
 * Override of woocommerce/templates/checkout/form-shipping.php.
 *
 * #ship-to-different-address-checkbox and the .shipping_address wrapper are
 * preserved exactly: checkout.js binds to the checkbox and slides that
 * wrapper, and the address fields are not submitted when it is hidden.
 *
 * @package Shop_GrozNet
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="woocommerce-shipping-fields space-y-5">

	<?php if ( true === WC()->cart->needs_shipping_address() ) : ?>

		<h3 id="ship-to-different-address" class="m-0">
			<label class="woocommerce-form__label woocommerce-form__label-for-checkbox checkbox inline-flex items-center gap-3 cursor-pointer">
				<input id="ship-to-different-address-checkbox"
					class="woocommerce-form__input woocommerce-form__input-checkbox input-checkbox sgz-checkbox"
					<?php checked( apply_filters( 'woocommerce_ship_to_different_address_checked', 'shipping' === get_option( 'woocommerce_ship_to_destination' ) ? 1 : 0 ), 1 ); ?>
					type="checkbox" name="ship_to_different_address" value="1" />
				<span class="text-base font-serif font-bold text-neutral-900 dark:text-white">
					<?php esc_html_e( 'Ship to a different address?', 'shop-groznet' ); ?>
				</span>
			</label>
		</h3>

		<div class="shipping_address space-y-5">

			<?php do_action( 'woocommerce_before_checkout_shipping_form', $checkout ); ?>

			<div class="woocommerce-shipping-fields__field-wrapper grid grid-cols-1 sm:grid-cols-2 gap-5">
				<?php
				$fields = $checkout->get_checkout_fields( 'shipping' );

				foreach ( $fields as $key => $field ) {
					woocommerce_form_field( $key, $field, $checkout->get_value( $key ) );
				}
				?>
			</div>

			<?php do_action( 'woocommerce_after_checkout_shipping_form', $checkout ); ?>

		</div>

	<?php endif; ?>
</div>

<div class="woocommerce-additional-fields space-y-5 pt-2">

	<?php do_action( 'woocommerce_before_order_notes', $checkout ); ?>

	<?php if ( apply_filters( 'woocommerce_enable_order_notes_field', 'yes' === get_option( 'woocommerce_enable_order_comments', 'yes' ) ) ) : ?>

		<?php if ( ! WC()->cart->needs_shipping() || wc_ship_to_billing_address_only() ) : ?>
			<h3 class="<?php sgz_ui_class( 'h3' ); ?>"><?php esc_html_e( 'Additional information', 'shop-groznet' ); ?></h3>
		<?php endif; ?>

		<div class="woocommerce-additional-fields__field-wrapper">
			<?php foreach ( $checkout->get_checkout_fields( 'order' ) as $key => $field ) : ?>
				<?php woocommerce_form_field( $key, $field, $checkout->get_value( $key ) ); ?>
			<?php endforeach; ?>
		</div>

	<?php endif; ?>

	<?php do_action( 'woocommerce_after_order_notes', $checkout ); ?>
</div>
