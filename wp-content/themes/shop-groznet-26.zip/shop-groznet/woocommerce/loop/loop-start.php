<?php
/**
 * Product loop wrapper (opening).
 *
 * Override of woocommerce/templates/loop/loop-start.php.
 *
 * Needed because the grid lives on this element: without the override the
 * cards from content-product.php would sit in WooCommerce's float-based
 * ul.products and the archive would not match the static site's 3-up grid.
 *
 * @package Shop_GrozNet
 */

defined( 'ABSPATH' ) || exit;
?>
<ul class="products grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 list-none p-0 m-0 columns-<?php echo esc_attr( wc_get_loop_prop( 'columns' ) ); ?>">
