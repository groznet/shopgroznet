<?php
/**
 * Catalogue ordering dropdown.
 *
 * Override of woocommerce/templates/loop/orderby.php.
 *
 * Field name (orderby), the paged hidden field and wc_query_string_form_fields()
 * are preserved exactly -- ordering breaks without them.
 *
 * @package Shop_GrozNet
 */

defined( 'ABSPATH' ) || exit;
?>
<form class="woocommerce-ordering flex items-center gap-3 m-0" method="get">
	<label class="<?php sgz_ui_class( 'label' ); ?> mb-0 hidden sm:block" for="sgz-orderby">
		<?php esc_html_e( 'Sort by', 'shop-groznet' ); ?>
	</label>

	<div class="relative">
		<select name="orderby" id="sgz-orderby" class="orderby <?php sgz_ui_class( 'select' ); ?> pr-10 py-2.5"
			aria-label="<?php esc_attr_e( 'Shop order', 'shop-groznet' ); ?>">
			<?php foreach ( $catalog_orderby_options as $id => $name ) : ?>
				<option value="<?php echo esc_attr( $id ); ?>" <?php selected( $orderby, $id ); ?>><?php echo esc_html( $name ); ?></option>
			<?php endforeach; ?>
		</select>
		<span class="absolute inset-y-0 right-3 flex items-center pointer-events-none text-neutral-400">
			<?php echo sgz_icon( 'chevron-down', 'w-4 h-4' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
		</span>
	</div>

	<input type="hidden" name="paged" value="1" />
	<?php wc_query_string_form_fields( null, array( 'orderby', 'submit', 'paged', 'product-page' ) ); ?>
</form>
