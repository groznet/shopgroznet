<?php
/**
 * Product archive: shop page, product categories/tags, and product search
 * results (WooCommerce routes product searches here).
 *
 * Override of woocommerce/templates/archive-product.php.
 *
 * Every do_action() from the original is preserved. The page shell comes
 * from sgz_wrapper_start()/sgz_wrapper_end(), hooked onto
 * woocommerce_before_main_content / woocommerce_after_main_content in
 * inc/woocommerce.php -- there is deliberately no root woocommerce.php,
 * which would take precedence over this file.
 *
 * @package Shop_GrozNet
 */

defined( 'ABSPATH' ) || exit;

get_header( 'shop' );

/**
 * Hook: woocommerce_before_main_content.
 *
 * @hooked sgz_wrapper_start - 10 (replaces woocommerce_output_content_wrapper)
 * @hooked woocommerce_breadcrumb - 20
 * @hooked WC_Structured_Data::generate_website_data() - 30
 */
do_action( 'woocommerce_before_main_content' );
?>

<header class="woocommerce-products-header max-w-3xl mb-12 space-y-4">

	<span class="<?php sgz_ui_class( 'eyebrow' ); ?>">
		<?php
		if ( is_search() ) {
			esc_html_e( 'Search', 'shop-groznet' );
		} elseif ( is_product_category() || is_product_tag() ) {
			esc_html_e( 'Catalogue', 'shop-groznet' );
		} else {
			esc_html_e( 'Shop', 'shop-groznet' );
		}
		?>
	</span>

	<h1 class="woocommerce-products-header__title page-title <?php sgz_ui_class( 'h1' ); ?>">
		<?php woocommerce_page_title(); ?>
	</h1>

	<div class="<?php sgz_ui_class( 'rule' ); ?>"></div>

	<div class="sgz-archive-description <?php sgz_ui_class( 'body' ); ?>">
		<?php
		/**
		 * Hook: woocommerce_archive_description.
		 *
		 * @hooked woocommerce_taxonomy_archive_description - 10
		 * @hooked woocommerce_product_archive_description - 10
		 */
		do_action( 'woocommerce_archive_description' );
		?>
	</div>

	<?php if ( is_search() ) : ?>
		<div class="max-w-xl pt-2"><?php get_search_form(); ?></div>
	<?php endif; ?>

</header>

<?php
if ( woocommerce_product_loop() ) {

	/*
	 * The notices wrapper is stretched to full width by woocommerce.css so it
	 * sits above the result count / ordering row rather than inside it.
	 */
	echo '<div class="sgz-loop-toolbar flex flex-wrap items-center justify-between gap-4 mb-8">';

	/**
	 * Hook: woocommerce_before_shop_loop.
	 *
	 * @hooked woocommerce_output_all_notices - 10
	 * @hooked woocommerce_result_count - 20
	 * @hooked woocommerce_catalog_ordering - 30
	 */
	do_action( 'woocommerce_before_shop_loop' );

	echo '</div>';

	woocommerce_product_loop_start();

	if ( wc_get_loop_prop( 'total' ) ) {
		while ( have_posts() ) {
			the_post();

			/**
			 * Hook: woocommerce_shop_loop.
			 */
			do_action( 'woocommerce_shop_loop' );

			wc_get_template_part( 'content', 'product' );
		}
	}

	woocommerce_product_loop_end();

	/**
	 * Hook: woocommerce_after_shop_loop.
	 *
	 * @hooked woocommerce_pagination - 10
	 */
	do_action( 'woocommerce_after_shop_loop' );
} else {
	/**
	 * Hook: woocommerce_no_products_found.
	 *
	 * @hooked wc_no_products_found - 10
	 */
	do_action( 'woocommerce_no_products_found' );
}

/**
 * Hook: woocommerce_after_main_content.
 *
 * @hooked sgz_wrapper_end - 10 (replaces woocommerce_output_content_wrapper_end)
 */
do_action( 'woocommerce_after_main_content' );

/**
 * Hook: woocommerce_sidebar.
 *
 * @hooked woocommerce_get_sidebar - 10 (unhooked when the widget area is empty)
 */
do_action( 'woocommerce_sidebar' );

get_footer( 'shop' );
