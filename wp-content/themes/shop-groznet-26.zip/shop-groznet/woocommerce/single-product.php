<?php
/**
 * Single product page.
 *
 * Override of woocommerce/templates/single-product.php.
 *
 * Structurally identical to the original -- it is a wrapper -- but it emits
 * the theme's header/footer and page shell. The real layout work happens in
 * content-single-product.php, which is why both are overridden together.
 *
 * @package Shop_GrozNet
 */

defined( 'ABSPATH' ) || exit;

get_header( 'shop' );

/**
 * Hook: woocommerce_before_main_content.
 *
 * @hooked sgz_wrapper_start - 10 (replaces woocommerce_output_content_wrapper)
 * @hooked woocommerce_breadcrumb - 20
 * @hooked WC_Structured_Data::generate_website_data() - 30
 */
do_action( 'woocommerce_before_main_content' );

while ( have_posts() ) {
	the_post();

	wc_get_template_part( 'content', 'single-product' );
}

/**
 * Hook: woocommerce_after_main_content.
 *
 * @hooked sgz_wrapper_end - 10 (replaces woocommerce_output_content_wrapper_end)
 */
do_action( 'woocommerce_after_main_content' );

/**
 * Hook: woocommerce_sidebar.
 *
 * @hooked woocommerce_get_sidebar - 10 (unhooked when the widget area is empty)
 */
do_action( 'woocommerce_sidebar' );

get_footer( 'shop' );
