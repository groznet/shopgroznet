<?php
/**
 * Site header.
 *
 * Shared by every template, including all WooCommerce pages (WooCommerce
 * calls get_header( 'shop' ), which falls back to this file).
 *
 * @package Shop_GrozNet
 */

defined( 'ABSPATH' ) || exit;
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="screen-reader-text" href="#main"><?php esc_html_e( 'Skip to content', 'shop-groznet' ); ?></a>

<div id="page" class="site min-h-screen flex flex-col">

	<header id="masthead"
		class="site-header sticky top-0 z-40 bg-white/95 dark:bg-neutral-900/95 backdrop-blur-sm border-b border-neutral-200/60 dark:border-neutral-800/60 transition-colors duration-300"
		x-data="{ mobileOpen: false, searchOpen: false }"
		@keydown.escape.window="mobileOpen = false; searchOpen = false">

		<div class="<?php sgz_ui_class( 'container' ); ?>">
			<div class="flex items-center justify-between gap-6 h-16 md:h-20">

				<div class="site-branding flex items-center gap-3 shrink-0">
					<?php
					if ( has_custom_logo() ) {
						the_custom_logo();
					} else {
						?>
						<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"
							class="text-xl md:text-2xl font-serif font-bold text-neutral-900 dark:text-white tracking-tight hover:text-brand-600 dark:hover:text-brand-400 transition-colors">
							<?php bloginfo( 'name' ); ?>
						</a>
						<?php
					}
					?>
				</div>

				<nav id="site-navigation" class="main-navigation hidden lg:block" aria-label="<?php esc_attr_e( 'Primary menu', 'shop-groznet' ); ?>">
					<?php
					if ( has_nav_menu( 'primary' ) ) {
						wp_nav_menu(
							array(
								'theme_location' => 'primary',
								'container'      => false,
								'menu_class'     => 'flex items-center gap-1',
								'depth'          => 2,
								'fallback_cb'    => false,
							)
						);
					}
					?>
				</nav>

				<div class="flex items-center gap-1.5 shrink-0">

					<button type="button"
						class="sgz-header-action p-2.5 rounded-xl text-neutral-600 dark:text-neutral-400 hover:text-brand-600 dark:hover:text-brand-400 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-all duration-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-brand-500"
						@click="searchOpen = !searchOpen; if (searchOpen) $nextTick(() => $refs.searchField && $refs.searchField.focus())"
						:aria-expanded="searchOpen ? 'true' : 'false'"
						aria-controls="sgz-header-search"
						aria-label="<?php esc_attr_e( 'Toggle search', 'shop-groznet' ); ?>">
						<?php echo sgz_icon( 'search', 'w-5 h-5' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
					</button>

					<button type="button"
						class="sgz-header-action sgz-color-scheme-toggle p-2.5 rounded-xl text-neutral-600 dark:text-neutral-400 hover:text-brand-600 dark:hover:text-brand-400 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-all duration-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-brand-500"
						aria-label="<?php esc_attr_e( 'Toggle dark theme', 'shop-groznet' ); ?>"
						aria-pressed="false">
						<span class="block dark:hidden"><?php echo sgz_icon( 'moon', 'w-5 h-5' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
						<span class="hidden dark:block"><?php echo sgz_icon( 'sun', 'w-5 h-5' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
					</button>

					<?php if ( function_exists( 'wc_get_cart_url' ) ) : ?>
						<a href="<?php echo esc_url( wc_get_account_endpoint_url( 'dashboard' ) ); ?>"
							class="sgz-header-action hidden sm:inline-flex p-2.5 rounded-xl text-neutral-600 dark:text-neutral-400 hover:text-brand-600 dark:hover:text-brand-400 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-all duration-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-brand-500"
							aria-label="<?php esc_attr_e( 'My account', 'shop-groznet' ); ?>">
							<?php echo sgz_icon( 'user', 'w-5 h-5' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
						</a>

						<button type="button"
							class="sgz-cart-toggle sgz-header-action relative p-2.5 rounded-xl text-neutral-600 dark:text-neutral-400 hover:text-brand-600 dark:hover:text-brand-400 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-all duration-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-brand-500"
							@click="$store.sgz.openCart()"
							:aria-expanded="$store.sgz.cartOpen ? 'true' : 'false'"
							aria-controls="sgz-cart-drawer"
							aria-label="<?php esc_attr_e( 'Open cart', 'shop-groznet' ); ?>">
							<?php
							echo sgz_icon( 'cart', 'w-5 h-5' ); // phpcs:ignore WordPress.Security.EscapeOutput
							sgz_cart_count_badge();
							?>
						</button>
					<?php endif; ?>

					<button type="button"
						class="sgz-header-action lg:hidden p-2.5 rounded-xl text-neutral-600 dark:text-neutral-400 hover:text-brand-600 dark:hover:text-brand-400 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-all duration-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-brand-500"
						@click="mobileOpen = !mobileOpen"
						:aria-expanded="mobileOpen ? 'true' : 'false'"
						aria-controls="sgz-mobile-menu"
						aria-label="<?php esc_attr_e( 'Toggle menu', 'shop-groznet' ); ?>">
						<span x-show="!mobileOpen"><?php echo sgz_icon( 'menu', 'w-6 h-6' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
						<span x-show="mobileOpen" x-cloak><?php echo sgz_icon( 'close', 'w-6 h-6' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
					</button>

				</div>
			</div>

			<div id="sgz-header-search" x-show="searchOpen" x-cloak x-collapse class="pb-5">
				<?php get_search_form(); ?>
			</div>

			<div id="sgz-mobile-menu" x-show="mobileOpen" x-cloak x-collapse class="lg:hidden pb-5">
				<?php
				if ( has_nav_menu( 'primary' ) ) {
					wp_nav_menu(
						array(
							'theme_location' => 'primary',
							'container'      => false,
							'menu_class'     => 'flex flex-col gap-1 border-t border-neutral-100 dark:border-neutral-800 pt-4',
							'depth'          => 2,
							'fallback_cb'    => false,
						)
					);
				}
				?>
			</div>
		</div>
	</header>

	<div id="content" class="site-content flex-1">
