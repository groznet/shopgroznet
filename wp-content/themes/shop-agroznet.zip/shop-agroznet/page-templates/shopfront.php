<?php
/**
 * Template Name: Shopfront
 * Template Post Type: page
 *
 * The landing page: what is in stock, what is moving, and where to start.
 * Assign it to a page and set that page as the front page.
 *
 * @package ShopAgroznet
 */

defined( 'ABSPATH' ) || exit;

get_header();

$agz_has_wc = function_exists( 'wc_get_page_permalink' );
?>

<main id="main" class="w-full">

	<!-- Hero: the depot board ------------------------------------------- -->
	<section class="border-b-2 border-ink bg-paper">
		<div class="mx-auto grid max-w-shell gap-10 px-4 py-16 sm:px-6 lg:grid-cols-[1.15fr_1fr] lg:items-end lg:gap-16 lg:px-8 lg:py-24">
			<div>
				<?php agz_row_marker( gmdate( 'F Y' ) . ' · ' . __( 'Depot board', 'shop-agroznet' ) ); ?>

				<h1 class="mt-8 font-display text-[3rem] font-extrabold uppercase leading-[0.88] tracking-stencil sm:text-[4.5rem] lg:text-[5.5rem]">
					<?php esc_html_e( 'Everything the', 'shop-agroznet' ); ?><br>
					<span class="text-field"><?php esc_html_e( 'season needs', 'shop-agroznet' ); ?></span><br>
					<?php esc_html_e( 'held in stock', 'shop-agroznet' ); ?>
				</h1>

				<p class="mt-8 max-w-md text-lg leading-relaxed text-ink/70">
					<?php esc_html_e( 'Seed, feed, crop protection and machinery parts. Priced per unit, quoted per pallet, and out of the door the same afternoon.', 'shop-agroznet' ); ?>
				</p>

				<?php if ( $agz_has_wc ) : ?>
					<div class="mt-10 flex flex-wrap gap-3">
						<a href="<?php echo esc_url( wc_get_page_permalink( 'shop' ) ); ?>" class="<?php echo esc_attr( agz_btn( 'solid' ) ); ?>">
							<?php esc_html_e( 'Browse the catalogue', 'shop-agroznet' ); ?>
						</a>
						<a href="<?php echo esc_url( wc_get_page_permalink( 'myaccount' ) ); ?>" class="<?php echo esc_attr( agz_btn( 'outline' ) ); ?>">
							<?php esc_html_e( 'Open a trade account', 'shop-agroznet' ); ?>
						</a>
					</div>
				<?php endif; ?>
			</div>

			<!-- Live stock board: real counts, not decoration -->
			<?php if ( $agz_has_wc ) : ?>
				<div class="border-2 border-ink bg-limewash shadow-tag">
					<div class="flex items-center justify-between border-b-2 border-ink px-5 py-3 font-mono text-[11px] uppercase tracking-label">
						<span><?php esc_html_e( 'Stock board', 'shop-agroznet' ); ?></span>
						<span class="flex items-center gap-2 text-field">
							<span class="h-2 w-2 bg-field"></span><?php esc_html_e( 'Live', 'shop-agroznet' ); ?>
						</span>
					</div>

					<dl class="divide-y divide-stone">
						<?php
						$agz_board = array();

						$agz_terms = get_terms(
							array(
								'taxonomy'   => 'product_cat',
								'hide_empty' => true,
								'number'     => 5,
								'orderby'    => 'count',
								'order'      => 'DESC',
							)
						);

						if ( ! is_wp_error( $agz_terms ) ) {
							foreach ( $agz_terms as $agz_term ) {
								$agz_board[] = array(
									'label' => $agz_term->name,
									'count' => $agz_term->count,
									'url'   => get_term_link( $agz_term ),
								);
							}
						}

						if ( empty( $agz_board ) ) {
							$agz_board[] = array(
								'label' => __( 'Add product categories to fill this board', 'shop-agroznet' ),
								'count' => 0,
								'url'   => '',
							);
						}

						foreach ( $agz_board as $agz_row ) :
							?>
							<div class="flex items-baseline justify-between gap-4 px-5 py-4">
								<dt class="font-display text-sm font-bold uppercase tracking-[0.04em]">
									<?php if ( $agz_row['url'] ) : ?>
										<a href="<?php echo esc_url( $agz_row['url'] ); ?>" class="hover:text-field"><?php echo esc_html( $agz_row['label'] ); ?></a>
									<?php else : ?>
										<?php echo esc_html( $agz_row['label'] ); ?>
									<?php endif; ?>
								</dt>
								<dd class="font-mono text-sm tabular-nums text-ink/60">
									<?php
									printf(
										/* translators: %d: number of product lines. */
										esc_html( _n( '%d line', '%d lines', (int) $agz_row['count'], 'shop-agroznet' ) ),
										(int) $agz_row['count']
									);
									?>
								</dd>
							</div>
						<?php endforeach; ?>
					</dl>
				</div>
			<?php endif; ?>
		</div>
	</section>

	<!-- Page content, if the editor added any --------------------------- -->
	<?php
	while ( have_posts() ) :
		the_post();

		if ( trim( get_the_content() ) ) :
			?>
			<section class="mx-auto max-w-3xl px-4 py-16 sm:px-6">
				<div class="agz-prose"><?php the_content(); ?></div>
			</section>
			<?php
		endif;
	endwhile;
	?>

	<!-- Moving this week -------------------------------------------------- -->
	<?php if ( $agz_has_wc ) : ?>
		<section class="mx-auto max-w-shell px-4 py-16 sm:px-6 lg:px-8">
			<?php agz_row_marker( __( 'Moving this week', 'shop-agroznet' ) ); ?>

			<div class="mt-8 flex flex-wrap items-end justify-between gap-4">
				<?php agz_heading( __( 'Best sellers from the depot', 'shop-agroznet' ), 'h2', 'text-3xl sm:text-5xl' ); ?>
				<a href="<?php echo esc_url( wc_get_page_permalink( 'shop' ) ); ?>" class="font-mono text-[11px] uppercase tracking-label text-field hover:underline">
					<?php esc_html_e( 'See the whole catalogue →', 'shop-agroznet' ); ?>
				</a>
			</div>

			<div class="mt-10">
				<?php echo do_shortcode( '[best_selling_products limit="3" columns="3"]' ); ?>
			</div>
		</section>

		<!-- Departments -->
		<section class="border-y-2 border-ink bg-paper">
			<div class="mx-auto max-w-shell px-4 py-16 sm:px-6 lg:px-8">
				<?php agz_row_marker( __( 'Departments', 'shop-agroznet' ) ); ?>
				<div class="mt-8"><?php echo do_shortcode( '[product_categories number="6" columns="3" parent="0"]' ); ?></div>
			</div>
		</section>
	<?php endif; ?>

	<!-- Journal ----------------------------------------------------------- -->
	<?php
	$agz_posts = new WP_Query(
		array(
			'posts_per_page'      => 3,
			'ignore_sticky_posts' => true,
		)
	);

	if ( $agz_posts->have_posts() ) :
		?>
		<section class="mx-auto max-w-shell px-4 py-16 sm:px-6 lg:px-8">
			<?php agz_row_marker( __( 'Field journal', 'shop-agroznet' ) ); ?>
			<div class="mt-8"><?php agz_heading( __( 'Notes from the ground', 'shop-agroznet' ), 'h2', 'text-3xl sm:text-5xl' ); ?></div>

			<div class="mt-10 grid gap-px bg-stone sm:grid-cols-2 lg:grid-cols-3">
				<?php
				while ( $agz_posts->have_posts() ) :
					$agz_posts->the_post();
					get_template_part( 'template-parts/content', 'post' );
				endwhile;
				?>
			</div>
		</section>
		<?php
		wp_reset_postdata();
	endif;
	?>
</main>

<?php
get_footer();
