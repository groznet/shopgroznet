<?php
/**
 * Site header. Shared by every template, WooCommerce included.
 *
 * @package ShopAgroznet
 */

defined( 'ABSPATH' ) || exit;

$agz_has_wc = function_exists( 'is_woocommerce' );
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-[60] focus:border-2 focus:border-ink focus:bg-tractor focus:px-4 focus:py-2 focus:font-display focus:text-sm focus:uppercase" href="#main">
	<?php esc_html_e( 'Skip to content', 'shop-agroznet' ); ?>
</a>

<div id="page" class="flex min-h-screen flex-col">

	<!-- Depot notice ------------------------------------------------------ -->
	<div class="bg-ink text-limewash">
		<div class="mx-auto flex max-w-shell items-center justify-between gap-4 px-4 py-2 sm:px-6 lg:px-8">
			<p class="font-mono text-[11px] uppercase tracking-label">
				<span class="mr-2 inline-block h-2 w-2 bg-tractor align-middle"></span>
				<?php
				echo esc_html(
					get_theme_mod(
						'agz_notice',
						__( 'Orders placed before 14:00 leave the depot the same working day', 'shop-agroznet' )
					)
				);
				?>
			</p>
			<div class="hidden items-center gap-6 font-mono text-[11px] uppercase tracking-label text-limewash/70 md:flex">
				<a href="tel:<?php echo esc_attr( get_theme_mod( 'agz_phone_raw', '+38765000000' ) ); ?>" class="hover:text-tractor">
					<?php echo esc_html( get_theme_mod( 'agz_phone', '+387 65 000 000' ) ); ?>
				</a>
				<?php if ( $agz_has_wc ) : ?>
					<a href="<?php echo esc_url( wc_get_page_permalink( 'myaccount' ) ); ?>" class="hover:text-tractor">
						<?php esc_html_e( 'Trade account', 'shop-agroznet' ); ?>
					</a>
				<?php endif; ?>
			</div>
		</div>
	</div>

	<!-- Masthead ---------------------------------------------------------- -->
	<header id="masthead"
		class="sticky top-0 z-50 border-b-2 border-ink bg-limewash/95 backdrop-blur supports-[backdrop-filter]:bg-limewash/85"
		x-data="{ mobile: false, search: false, cart: false }"
		@keydown.escape.window="mobile = false; search = false; cart = false"
		@open-cart.window="cart = true">

		<div class="mx-auto flex max-w-shell items-center gap-4 px-4 py-4 sm:px-6 lg:px-8">

			<!-- Brand -->
			<div class="flex items-center gap-3">
				<?php if ( has_custom_logo() ) : ?>
					<?php the_custom_logo(); ?>
				<?php else : ?>
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="group flex items-center gap-3" rel="home">
						<span class="grid h-10 w-10 place-items-center border-2 border-ink bg-field text-limewash transition-transform group-hover:-translate-y-[2px] group-hover:shadow-tag-sm">
							<svg class="h-5 w-5" viewBox="0 0 24 24" fill="none" aria-hidden="true">
								<path d="M12 21V9" stroke="currentColor" stroke-width="2"/>
								<path d="M12 12c0-4 3-7 8-7 0 5-3 8-8 8Z" fill="currentColor"/>
								<path d="M12 16c0-3-2.2-5.5-6-5.5 0 3.8 2.4 6 6 6Z" fill="currentColor" opacity=".55"/>
							</svg>
						</span>
						<span class="leading-none">
							<span class="block font-display text-xl font-extrabold uppercase tracking-stencil text-ink"><?php bloginfo( 'name' ); ?></span>
							<span class="mt-1 block font-mono text-[10px] uppercase tracking-label text-ink/55">
								<?php echo esc_html( get_bloginfo( 'description' ) ? get_bloginfo( 'description' ) : __( 'Agricultural supply', 'shop-agroznet' ) ); ?>
							</span>
						</span>
					</a>
				<?php endif; ?>
			</div>

			<!-- Primary navigation -->
			<nav class="ml-6 hidden lg:block" aria-label="<?php esc_attr_e( 'Primary', 'shop-agroznet' ); ?>">
				<?php
				wp_nav_menu(
					array(
						'theme_location' => 'primary',
						'container'      => false,
						'menu_class'     => 'flex items-center gap-7',
						'depth'          => 2,
						'walker'         => new AGZ_Nav_Walker(),
						'fallback_cb'    => false,
					)
				);
				?>
			</nav>

			<div class="ml-auto flex items-center gap-2">

				<!-- Search toggle -->
				<button type="button"
					@click="search = !search; $nextTick(() => search && $refs.searchField?.focus())"
					class="inline-flex items-center gap-2 border-2 border-ink bg-paper px-3 py-2 transition-transform hover:-translate-y-[2px] hover:shadow-tag-sm"
					:aria-expanded="search ? 'true' : 'false'">
					<svg class="h-4 w-4" viewBox="0 0 20 20" fill="none" aria-hidden="true">
						<circle cx="9" cy="9" r="6" stroke="currentColor" stroke-width="1.8"/>
						<path d="m13.5 13.5 4 4" stroke="currentColor" stroke-width="1.8" stroke-linecap="square"/>
					</svg>
					<span class="hidden font-mono text-[11px] uppercase tracking-label sm:inline"><?php esc_html_e( 'Search', 'shop-agroznet' ); ?></span>
				</button>

				<?php if ( $agz_has_wc ) : ?>
					<div class="agz-cart-fragment"><?php agz_cart_button(); ?></div>
				<?php endif; ?>

				<!-- Mobile menu -->
				<button type="button" @click="mobile = true"
					class="inline-flex items-center border-2 border-ink bg-paper px-3 py-2 lg:hidden"
					aria-label="<?php esc_attr_e( 'Open menu', 'shop-agroznet' ); ?>">
					<svg class="h-4 w-4" viewBox="0 0 20 20" aria-hidden="true">
						<path d="M2 5h16M2 10h16M2 15h16" stroke="currentColor" stroke-width="2"/>
					</svg>
				</button>
			</div>
		</div>

		<!-- Departments strip -->
		<?php if ( has_nav_menu( 'departments' ) ) : ?>
			<div class="hidden border-t border-ink/15 lg:block">
				<div class="mx-auto max-w-shell px-4 sm:px-6 lg:px-8">
					<?php
					wp_nav_menu(
						array(
							'theme_location' => 'departments',
							'container'      => false,
							'menu_class'     => 'flex items-center gap-6 overflow-x-auto py-2.5 font-mono text-[11px] uppercase tracking-label text-ink/70 [&_a]:whitespace-nowrap [&_a:hover]:text-field',
							'depth'          => 1,
							'fallback_cb'    => false,
						)
					);
					?>
				</div>
			</div>
		<?php endif; ?>

		<!-- Search panel ---------------------------------------------------- -->
		<div x-show="search" x-cloak x-transition.origin.top.duration.200ms
			class="border-t-2 border-ink bg-paper">
			<div class="mx-auto max-w-shell px-4 py-6 sm:px-6 lg:px-8">
				<form role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" class="flex flex-col gap-3 sm:flex-row">
					<?php if ( $agz_has_wc ) : ?>
						<input type="hidden" name="post_type" value="product">
					<?php endif; ?>
					<label class="sr-only" for="agz-search-field"><?php esc_html_e( 'Search products', 'shop-agroznet' ); ?></label>
					<input id="agz-search-field" x-ref="searchField" type="search" name="s"
						value="<?php echo esc_attr( get_search_query() ); ?>"
						placeholder="<?php esc_attr_e( 'Seed, feed, parts, SKU…', 'shop-agroznet' ); ?>"
						class="w-full border-2 border-ink bg-limewash px-4 py-3 font-body text-base placeholder:text-ink/40 focus:outline-none focus:ring-2 focus:ring-field focus:ring-offset-2">
					<button type="submit" class="<?php echo esc_attr( agz_btn( 'accent' ) ); ?> sm:w-48"><?php esc_html_e( 'Search', 'shop-agroznet' ); ?></button>
				</form>
				<p class="mt-3 font-mono text-[11px] uppercase tracking-label text-ink/50">
					<?php esc_html_e( 'Tip: search by SKU for an exact match', 'shop-agroznet' ); ?>
				</p>
			</div>
		</div>

		<!-- Mobile drawer ---------------------------------------------------- -->
		<div x-show="mobile" x-cloak class="fixed inset-0 z-[60] lg:hidden" x-trap.noscroll="mobile" role="dialog" aria-modal="true">
			<div x-show="mobile" x-transition.opacity class="absolute inset-0 bg-ink/60" @click="mobile = false"></div>
			<div x-show="mobile"
				x-transition:enter="transition ease-out duration-200" x-transition:enter-start="translate-x-full" x-transition:enter-end="translate-x-0"
				x-transition:leave="transition ease-in duration-150" x-transition:leave-start="translate-x-0" x-transition:leave-end="translate-x-full"
				class="absolute right-0 top-0 flex h-full w-[86%] max-w-sm flex-col border-l-2 border-ink bg-limewash">
				<div class="flex items-center justify-between border-b-2 border-ink px-5 py-4">
					<span class="font-mono text-[11px] uppercase tracking-label text-ink/55"><?php esc_html_e( 'Menu', 'shop-agroznet' ); ?></span>
					<button type="button" @click="mobile = false" class="border-2 border-ink px-2 py-1" aria-label="<?php esc_attr_e( 'Close menu', 'shop-agroznet' ); ?>">
						<svg class="h-4 w-4" viewBox="0 0 20 20" aria-hidden="true"><path d="M4 4l12 12M16 4L4 16" stroke="currentColor" stroke-width="2"/></svg>
					</button>
				</div>
				<div class="flex-1 overflow-y-auto px-5 py-6">
					<?php
					wp_nav_menu(
						array(
							'theme_location' => 'primary',
							'container'      => false,
							'menu_class'     => 'space-y-2',
							'depth'          => 2,
							'walker'         => new AGZ_Mobile_Nav_Walker(),
							'fallback_cb'    => false,
						)
					);
					?>
					<?php if ( has_nav_menu( 'departments' ) ) : ?>
						<div class="mt-8"><?php agz_row_marker( __( 'Departments', 'shop-agroznet' ) ); ?></div>
						<?php
						wp_nav_menu(
							array(
								'theme_location' => 'departments',
								'container'      => false,
								'menu_class'     => 'mt-4 space-y-3 font-mono text-xs uppercase tracking-label text-ink/70',
								'depth'          => 1,
								'fallback_cb'    => false,
							)
						);
						?>
					<?php endif; ?>
				</div>
				<?php if ( $agz_has_wc ) : ?>
					<div class="border-t-2 border-ink p-5">
						<a href="<?php echo esc_url( wc_get_page_permalink( 'myaccount' ) ); ?>" class="<?php echo esc_attr( agz_btn( 'outline' ) ); ?> w-full">
							<?php esc_html_e( 'Trade account', 'shop-agroznet' ); ?>
						</a>
					</div>
				<?php endif; ?>
			</div>
		</div>

		<!-- Order drawer ----------------------------------------------------- -->
		<?php if ( $agz_has_wc ) : ?>
			<div x-show="cart" x-cloak class="fixed inset-0 z-[60]" x-trap.noscroll="cart" role="dialog" aria-modal="true" aria-label="<?php esc_attr_e( 'Your order', 'shop-agroznet' ); ?>">
				<div x-show="cart" x-transition.opacity class="absolute inset-0 bg-ink/60" @click="cart = false"></div>
				<div x-show="cart"
					x-transition:enter="transition ease-out duration-200" x-transition:enter-start="translate-x-full" x-transition:enter-end="translate-x-0"
					x-transition:leave="transition ease-in duration-150" x-transition:leave-start="translate-x-0" x-transition:leave-end="translate-x-full"
					class="absolute right-0 top-0 flex h-full w-[92%] max-w-md flex-col border-l-2 border-ink bg-limewash">
					<div class="flex items-center justify-between border-b-2 border-ink px-5 py-4">
						<span class="font-display text-lg font-extrabold uppercase tracking-stencil"><?php esc_html_e( 'Your order', 'shop-agroznet' ); ?></span>
						<button type="button" @click="cart = false" class="border-2 border-ink px-2 py-1" aria-label="<?php esc_attr_e( 'Close order', 'shop-agroznet' ); ?>">
							<svg class="h-4 w-4" viewBox="0 0 20 20" aria-hidden="true"><path d="M4 4l12 12M16 4L4 16" stroke="currentColor" stroke-width="2"/></svg>
						</button>
					</div>
					<div class="agz-drawer-fragment flex flex-1 flex-col overflow-hidden">
						<?php get_template_part( 'template-parts/cart-drawer-contents' ); ?>
					</div>
				</div>
			</div>
		<?php endif; ?>
	</header>
