<?php
/**
 * Fallback template — the field journal listing.
 *
 * @package ShopAgroznet
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>

<main id="main" class="mx-auto w-full max-w-shell px-4 pb-24 pt-10 sm:px-6 lg:px-8">

	<header class="mb-12">
		<?php agz_row_marker( __( 'Field journal', 'shop-agroznet' ) ); ?>
		<h1 class="mt-5 max-w-3xl font-display text-4xl font-extrabold uppercase leading-[0.95] tracking-stencil sm:text-6xl">
			<?php
			if ( is_home() && ! is_front_page() ) {
				echo esc_html( get_the_title( get_option( 'page_for_posts' ) ) );
			} else {
				esc_html_e( 'Notes from the ground', 'shop-agroznet' );
			}
			?>
		</h1>
		<p class="mt-4 max-w-xl text-base text-ink/70">
			<?php esc_html_e( 'Trial results, seasonal timings and equipment notes from the depot team.', 'shop-agroznet' ); ?>
		</p>
	</header>

	<?php if ( have_posts() ) : ?>
		<div class="grid gap-px bg-stone sm:grid-cols-2 lg:grid-cols-3">
			<?php
			while ( have_posts() ) :
				the_post();
				get_template_part( 'template-parts/content', get_post_type() );
			endwhile;
			?>
		</div>

		<div class="agz-pagination mt-12">
			<?php
			the_posts_pagination(
				array(
					'mid_size'  => 1,
					'prev_text' => __( 'Previous', 'shop-agroznet' ),
					'next_text' => __( 'Next', 'shop-agroznet' ),
				)
			);
			?>
		</div>
	<?php else : ?>
		<div class="border-2 border-ink bg-paper p-10 text-center">
			<p class="font-display text-xl font-bold uppercase tracking-stencil"><?php esc_html_e( 'Nothing published yet', 'shop-agroznet' ); ?></p>
			<p class="mt-2 text-sm text-ink/70"><?php esc_html_e( 'The first entries go up at the start of the season.', 'shop-agroznet' ); ?></p>
		</div>
	<?php endif; ?>
</main>

<?php
get_footer();
