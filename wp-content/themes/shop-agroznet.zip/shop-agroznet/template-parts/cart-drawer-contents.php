<?php
/**
 * Contents of the slide-over order drawer.
 *
 * Re-rendered through woocommerce_add_to_cart_fragments, so it must not depend
 * on anything outside the cart object.
 *
 * @package ShopAgroznet
 */

defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
	return;
}

$agz_cart  = WC()->cart;
$agz_items = $agz_cart->get_cart();
?>

<?php if ( empty( $agz_items ) ) : ?>

	<div class="flex flex-1 flex-col items-center justify-center gap-5 px-8 text-center">
		<span class="grid h-14 w-14 place-items-center border-2 border-ink bg-paper">
			<svg class="h-6 w-6 text-ink/40" viewBox="0 0 24 24" fill="none" aria-hidden="true">
				<path d="M3 4h3l2.6 11.2A1.7 1.7 0 0 0 10.3 16.5h7.4a1.7 1.7 0 0 0 1.66-1.3L21 7H7" stroke="currentColor" stroke-width="1.8" stroke-linecap="square"/>
			</svg>
		</span>
		<p class="font-display text-lg font-bold uppercase tracking-stencil"><?php esc_html_e( 'Nothing loaded yet', 'shop-agroznet' ); ?></p>
		<p class="max-w-[16rem] text-sm text-ink/70"><?php esc_html_e( 'Browse the depot and add what you need. Items stay here for 30 days.', 'shop-agroznet' ); ?></p>
		<a href="<?php echo esc_url( wc_get_page_permalink( 'shop' ) ); ?>" class="<?php echo esc_attr( agz_btn( 'solid' ) ); ?>">
			<?php esc_html_e( 'Browse the depot', 'shop-agroznet' ); ?>
		</a>
	</div>

<?php else : ?>

	<ul class="flex-1 divide-y divide-stone overflow-y-auto px-5">
		<?php
		foreach ( $agz_items as $agz_key => $agz_item ) {
			$agz_product = apply_filters( 'woocommerce_cart_item_product', $agz_item['data'], $agz_item, $agz_key );

			if ( ! $agz_product || ! $agz_product->exists() || $agz_item['quantity'] <= 0 ) {
				continue;
			}

			$agz_name  = apply_filters( 'woocommerce_cart_item_name', $agz_product->get_name(), $agz_item, $agz_key );
			$agz_link  = $agz_product->is_visible() ? $agz_product->get_permalink( $agz_item ) : '';
			$agz_thumb = $agz_product->get_image( 'woocommerce_thumbnail', array( 'class' => 'h-full w-full object-cover' ) );
			?>
			<li class="flex gap-4 py-5">
				<span class="h-20 w-20 shrink-0 overflow-hidden border-2 border-ink bg-paper">
					<?php echo wp_kses_post( $agz_thumb ); ?>
				</span>
				<div class="min-w-0 flex-1">
					<p class="font-mono text-[10px] uppercase tracking-label text-ink/50"><?php echo esc_html( agz_plot_code( $agz_product->get_id() ) ); ?></p>
					<p class="mt-1 truncate font-display text-sm font-bold uppercase tracking-[0.04em]">
						<?php if ( $agz_link ) : ?>
							<a href="<?php echo esc_url( $agz_link ); ?>" class="hover:text-field"><?php echo wp_kses_post( $agz_name ); ?></a>
						<?php else : ?>
							<?php echo wp_kses_post( $agz_name ); ?>
						<?php endif; ?>
					</p>
					<?php echo wp_kses_post( wc_get_formatted_cart_item_data( $agz_item ) ); ?>
					<div class="mt-2 flex items-center justify-between gap-3">
						<span class="font-mono text-xs text-ink/70">
							<?php
							printf(
								'%d &times; %s',
								(int) $agz_item['quantity'],
								wp_kses_post( WC()->cart->get_product_price( $agz_product ) )
							);
							?>
						</span>
						<a href="<?php echo esc_url( wc_get_cart_remove_url( $agz_key ) ); ?>"
							class="font-mono text-[10px] uppercase tracking-label text-clay underline underline-offset-4 hover:no-underline"
							aria-label="<?php echo esc_attr( sprintf( __( 'Remove %s from your order', 'shop-agroznet' ), wp_strip_all_tags( $agz_name ) ) ); ?>">
							<?php esc_html_e( 'Remove', 'shop-agroznet' ); ?>
						</a>
					</div>
				</div>
			</li>
			<?php
		}
		?>
	</ul>

	<div class="border-t-2 border-ink bg-paper px-5 py-5">
		<div class="flex items-baseline justify-between">
			<span class="font-mono text-[11px] uppercase tracking-label text-ink/60"><?php esc_html_e( 'Subtotal', 'shop-agroznet' ); ?></span>
			<span class="font-mono text-lg font-semibold"><?php echo wp_kses_post( $agz_cart->get_cart_subtotal() ); ?></span>
		</div>
		<p class="mt-1 font-mono text-[10px] uppercase tracking-label text-ink/45"><?php esc_html_e( 'Delivery calculated at checkout', 'shop-agroznet' ); ?></p>
		<div class="mt-4 grid gap-2">
			<a href="<?php echo esc_url( wc_get_checkout_url() ); ?>" class="<?php echo esc_attr( agz_btn( 'solid' ) ); ?> w-full"><?php esc_html_e( 'Go to checkout', 'shop-agroznet' ); ?></a>
			<a href="<?php echo esc_url( wc_get_cart_url() ); ?>" class="<?php echo esc_attr( agz_btn( 'outline' ) ); ?> w-full"><?php esc_html_e( 'Review the order', 'shop-agroznet' ); ?></a>
		</div>
	</div>

<?php endif; ?>
