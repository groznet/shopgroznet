<?php
/**
 * Journal card used in listings.
 *
 * @package ShopAgroznet
 */

defined( 'ABSPATH' ) || exit;
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'group flex flex-col bg-limewash p-6 transition-colors hover:bg-paper' ); ?>>
	<?php if ( has_post_thumbnail() ) : ?>
		<a href="<?php the_permalink(); ?>" class="mb-5 block overflow-hidden border-2 border-ink bg-paper" tabindex="-1" aria-hidden="true">
			<?php
			the_post_thumbnail(
				'medium_large',
				array( 'class' => 'aspect-[4/3] w-full object-cover transition-transform duration-300 group-hover:scale-[1.03]' )
			);
			?>
		</a>
	<?php endif; ?>

	<?php agz_post_meta(); ?>

	<h2 class="mt-3 font-display text-xl font-bold uppercase leading-tight tracking-stencil">
		<a href="<?php the_permalink(); ?>" class="hover:text-field"><?php the_title(); ?></a>
	</h2>

	<p class="mt-3 flex-1 text-sm leading-relaxed text-ink/70"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 24 ) ); ?></p>

	<a href="<?php the_permalink(); ?>" class="mt-5 inline-flex items-center gap-2 font-mono text-[11px] uppercase tracking-label text-field">
		<?php esc_html_e( 'Read the note', 'shop-agroznet' ); ?>
		<span aria-hidden="true">&rarr;</span>
	</a>
</article>
