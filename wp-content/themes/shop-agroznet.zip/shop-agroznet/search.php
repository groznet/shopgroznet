<?php
/**
 * Search results.
 *
 * A product-only search (?post_type=product) is routed by WooCommerce to
 * woocommerce/archive-product.php. This template handles everything else and
 * still surfaces matching products at the top, so one search box serves the
 * whole site.
 *
 * @package ShopAgroznet
 */

defined( 'ABSPATH' ) || exit;

get_header();

$agz_term     = get_search_query();
$agz_products = null;

if ( function_exists( 'wc_get_product' ) && $agz_term ) {
	$agz_products = new WP_Query(
		array(
			'post_type'           => 'product',
			's'                   => $agz_term,
			'posts_per_page'      => 3,
			'ignore_sticky_posts' => true,
			'no_found_rows'       => false,
			'post_status'         => 'publish',
			'tax_query'           => array( // phpcs:ignore WordPress.DB.SlowDBQuery
				array(
					'taxonomy' => 'product_visibility',
					'field'    => 'name',
					'terms'    => array( 'exclude-from-search' ),
					'operator' => 'NOT IN',
				),
			),
		)
	);
}
?>

<main id="main" class="mx-auto w-full max-w-shell px-4 pb-24 pt-10 sm:px-6 lg:px-8">

	<header class="border-b-2 border-ink pb-8">
		<?php agz_breadcrumb(); ?>
		<h1 class="mt-5 font-display text-3xl font-extrabold uppercase leading-[0.98] tracking-stencil sm:text-5xl">
			<?php
			printf(
				/* translators: %s: search term. */
				esc_html__( 'Results for “%s”', 'shop-agroznet' ),
				esc_html( $agz_term )
			);
			?>
		</h1>

		<div class="mt-6 max-w-2xl"><?php get_search_form(); ?></div>

		<p class="mt-4 font-mono text-[11px] uppercase tracking-label text-ink/55">
			<?php
			$agz_product_count = $agz_products ? (int) $agz_products->found_posts : 0;
			$agz_content_count = (int) $GLOBALS['wp_query']->found_posts;
			printf(
				/* translators: 1: number of products, 2: number of pages and posts. */
				esc_html__( '%1$s in the catalogue / %2$s elsewhere on the site', 'shop-agroznet' ),
				esc_html( sprintf( _n( '%d product', '%d products', $agz_product_count, 'shop-agroznet' ), $agz_product_count ) ),
				esc_html( sprintf( _n( '%d result', '%d results', $agz_content_count, 'shop-agroznet' ), $agz_content_count ) )
			);
			?>
		</p>
	</header>

	<?php if ( $agz_products && $agz_products->have_posts() ) : ?>
		<section class="mt-14">
			<?php agz_row_marker( __( 'From the catalogue', 'shop-agroznet' ) ); ?>

			<div class="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
				<?php
				while ( $agz_products->have_posts() ) :
					$agz_products->the_post();
					wc_get_template_part( 'content', 'product' );
				endwhile;
				?>
			</div>

			<?php if ( $agz_products->found_posts > 3 ) : ?>
				<a href="<?php echo esc_url( add_query_arg( array( 's' => rawurlencode( $agz_term ), 'post_type' => 'product' ), home_url( '/' ) ) ); ?>"
					class="<?php echo esc_attr( agz_btn( 'outline' ) ); ?> mt-8">
					<?php
					printf(
						/* translators: %d: total matching products. */
						esc_html__( 'See all %d matching products', 'shop-agroznet' ),
						(int) $agz_products->found_posts
					);
					?>
				</a>
			<?php endif; ?>
		</section>
		<?php wp_reset_postdata(); ?>
	<?php endif; ?>

	<section class="mt-16">
		<?php agz_row_marker( __( 'Pages and journal entries', 'shop-agroznet' ) ); ?>

		<?php if ( have_posts() ) : ?>
			<ul class="mt-6 divide-y-2 divide-stone border-y-2 border-ink">
				<?php
				while ( have_posts() ) :
					the_post();
					?>
					<li class="group py-6">
						<a href="<?php the_permalink(); ?>" class="flex flex-col gap-2 sm:flex-row sm:items-baseline sm:gap-8">
							<span class="w-32 shrink-0 font-mono text-[11px] uppercase tracking-label text-ink/45">
								<?php echo esc_html( get_post_type_object( get_post_type() )->labels->singular_name ); ?>
							</span>
							<span class="flex-1">
								<span class="block font-display text-lg font-bold uppercase tracking-stencil group-hover:text-field"><?php the_title(); ?></span>
								<span class="mt-1 block text-sm text-ink/65"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 26 ) ); ?></span>
							</span>
						</a>
					</li>
					<?php
				endwhile;
				?>
			</ul>

			<div class="agz-pagination mt-10"><?php the_posts_pagination( array( 'mid_size' => 1 ) ); ?></div>

		<?php else : ?>
			<div class="mt-6 border-2 border-ink bg-paper p-10">
				<p class="font-display text-xl font-bold uppercase tracking-stencil"><?php esc_html_e( 'No pages matched', 'shop-agroznet' ); ?></p>
				<p class="mt-2 max-w-md text-sm text-ink/70">
					<?php esc_html_e( 'Try a shorter term, a product SKU, or browse the departments in the menu.', 'shop-agroznet' ); ?>
				</p>
			</div>
		<?php endif; ?>
	</section>
</main>

<?php
get_footer();
