<?php
/**
 * Styles, scripts and design tokens.
 *
 * Tailwind can run two ways:
 *  1. Production — run `npm run build`, which compiles src/tailwind.css to
 *     assets/css/tailwind.build.css. If that file exists the theme uses it.
 *  2. No build step — the theme falls back to the Tailwind browser runtime and
 *     injects the same token set inline, so the design is identical.
 *
 * @package ShopAgroznet
 */

defined( 'ABSPATH' ) || exit;

/**
 * Single source of truth for the palette and type stack.
 *
 * Mirrored in tailwind.config.js for the compiled build.
 *
 * @return array
 */
function agz_design_tokens() {
	return array(
		'colors' => array(
			'ink'      => '#16261C',
			'field'    => '#1F6F43',
			'field-700' => '#175634',
			'tractor'  => '#F2C230',
			'clay'     => '#B4532A',
			'limewash' => '#F1F3EC',
			'stone'    => '#DCDFD3',
			'paper'    => '#FBFCF8',
		),
		'fonts'  => array(
			'display' => '"Archivo", "Arial Narrow", system-ui, sans-serif',
			'body'    => '"Public Sans", system-ui, -apple-system, sans-serif',
			'mono'    => '"IBM Plex Mono", ui-monospace, SFMono-Regular, monospace',
		),
	);
}

/**
 * The Tailwind config object shared by the build and the browser runtime.
 *
 * @return string JSON-ish JS object literal.
 */
function agz_tailwind_config_js() {
	$tokens = agz_design_tokens();

	$config = array(
		'theme' => array(
			'extend' => array(
				'colors'       => $tokens['colors'],
				'fontFamily'   => array(
					'display' => array( 'Archivo', 'Arial Narrow', 'system-ui', 'sans-serif' ),
					'body'    => array( 'Public Sans', 'system-ui', 'sans-serif' ),
					'mono'    => array( 'IBM Plex Mono', 'ui-monospace', 'monospace' ),
				),
				'letterSpacing' => array(
					'stencil' => '-0.02em',
					'label'   => '0.18em',
				),
				'boxShadow'    => array(
					'tag'      => '4px 4px 0 0 #16261C',
					'tag-sm'   => '3px 3px 0 0 #16261C',
					'tag-lift' => '6px 6px 0 0 #16261C',
					'field'    => '4px 4px 0 0 #1F6F43',
				),
				'borderRadius' => array(
					'none' => '0px',
				),
				'maxWidth'     => array(
					'shell' => '84rem',
				),
			),
		),
	);

	return wp_json_encode( $config );
}

/**
 * Front-end assets.
 */
function agz_enqueue_assets() {
	$tokens   = agz_design_tokens();
	$build    = AGZ_DIR . '/assets/css/tailwind.build.css';
	$has_build = file_exists( $build );

	// Typefaces.
	wp_enqueue_style(
		'agz-fonts',
		'https://fonts.googleapis.com/css2?family=Archivo:wght@500;600;700;800&family=IBM+Plex+Mono:wght@400;500;600&family=Public+Sans:wght@400;500;600&display=swap',
		array(),
		null
	);

	if ( $has_build ) {
		wp_enqueue_style(
			'agz-tailwind',
			AGZ_URI . '/assets/css/tailwind.build.css',
			array( 'agz-fonts' ),
			filemtime( $build )
		);
	} else {
		// Browser runtime fallback — no build step required.
		wp_enqueue_script( 'agz-tailwind-runtime', 'https://cdn.tailwindcss.com/3.4.16', array(), null, false );
		wp_add_inline_script( 'agz-tailwind-runtime', 'tailwind.config = ' . agz_tailwind_config_js() . ';', 'after' );
	}

	// Hand-written CSS for markup the theme does not author (WooCommerce output).
	wp_enqueue_style(
		'agz-theme',
		AGZ_URI . '/assets/css/theme.css',
		array( 'agz-fonts' ),
		AGZ_VERSION
	);

	// Expose tokens to CSS custom properties for the same reason.
	$vars = ':root{';
	foreach ( $tokens['colors'] as $name => $hex ) {
		$vars .= '--agz-' . $name . ':' . $hex . ';';
	}
	foreach ( $tokens['fonts'] as $name => $stack ) {
		$vars .= '--agz-font-' . $name . ':' . $stack . ';';
	}
	$vars .= '}';
	wp_add_inline_style( 'agz-theme', $vars );

	// Alpine.js — deferred so it initialises after markup is parsed.
	wp_enqueue_script( 'agz-alpine-focus', 'https://cdn.jsdelivr.net/npm/@alpinejs/focus@3.14.8/dist/cdn.min.js', array(), null, array( 'strategy' => 'defer' ) );
	wp_enqueue_script( 'agz-alpine', 'https://cdn.jsdelivr.net/npm/alpinejs@3.14.8/dist/cdn.min.js', array( 'agz-alpine-focus' ), null, array( 'strategy' => 'defer' ) );

	// Theme behaviour that is not worth an Alpine component.
	wp_enqueue_script(
		'agz-theme',
		AGZ_URI . '/assets/js/theme.js',
		array(),
		AGZ_VERSION,
		array( 'strategy' => 'defer' )
	);

	wp_localize_script(
		'agz-theme',
		'agzData',
		array(
			'ajaxUrl'   => admin_url( 'admin-ajax.php' ),
			'isShop'    => function_exists( 'is_woocommerce' ) && is_woocommerce(),
			'cartUrl'   => function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : '',
			'i18n'      => array(
				'added'   => __( 'Added to order', 'shop-agroznet' ),
				'adding'  => __( 'Adding…', 'shop-agroznet' ),
			),
		)
	);

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'agz_enqueue_assets' );

/**
 * Alpine needs `x-cloak` hidden before it boots.
 */
function agz_cloak_style() {
	echo '<style>[x-cloak]{display:none!important}</style>' . "\n";
}
add_action( 'wp_head', 'agz_cloak_style', 1 );

/**
 * Editor styles so block content roughly matches the front end.
 */
function agz_editor_assets() {
	wp_enqueue_style( 'agz-editor', AGZ_URI . '/assets/css/theme.css', array(), AGZ_VERSION );
}
add_action( 'enqueue_block_editor_assets', 'agz_editor_assets' );
