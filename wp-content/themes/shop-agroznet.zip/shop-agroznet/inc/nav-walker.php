<?php
/**
 * Navigation walker: two-level menus with Alpine-driven dropdowns.
 *
 * @package ShopAgroznet
 */

defined( 'ABSPATH' ) || exit;

/**
 * Desktop primary navigation walker.
 */
class AGZ_Nav_Walker extends Walker_Nav_Menu {

	/**
	 * Start a submenu level.
	 *
	 * @param string   $output Output.
	 * @param int      $depth  Depth.
	 * @param stdClass $args   Args.
	 */
	public function start_lvl( &$output, $depth = 0, $args = null ) {
		$output .= '<ul x-show="open" x-cloak x-transition.opacity.duration.150ms @click.outside="open = false" class="absolute left-0 top-full z-40 min-w-[15rem] border-2 border-ink bg-paper py-2 shadow-tag">';
	}

	/**
	 * End a submenu level.
	 *
	 * @param string   $output Output.
	 * @param int      $depth  Depth.
	 * @param stdClass $args   Args.
	 */
	public function end_lvl( &$output, $depth = 0, $args = null ) {
		$output .= '</ul>';
	}

	/**
	 * Start an element.
	 *
	 * @param string   $output Output.
	 * @param WP_Post  $item   Menu item.
	 * @param int      $depth  Depth.
	 * @param stdClass $args   Args.
	 * @param int      $id     ID.
	 */
	public function start_el( &$output, $item, $depth = 0, $args = null, $id = 0 ) {
		$has_children = in_array( 'menu-item-has-children', (array) $item->classes, true );
		$is_current   = in_array( 'current-menu-item', (array) $item->classes, true ) || in_array( 'current-menu-ancestor', (array) $item->classes, true );

		if ( 0 === $depth ) {
			$li_class = 'relative';
			$li_attr  = $has_children ? ' x-data="{ open: false }" @keydown.escape="open = false"' : '';
			$a_class  = 'inline-flex items-center gap-1.5 py-2 font-display text-[13px] font-semibold uppercase tracking-[0.08em] transition-colors hover:text-field ' . ( $is_current ? 'text-field' : 'text-ink' );
		} else {
			$li_class = '';
			$li_attr  = '';
			$a_class  = 'block px-4 py-2 font-body text-sm text-ink/80 transition-colors hover:bg-limewash hover:text-field ' . ( $is_current ? 'text-field' : '' );
		}

		$output .= '<li class="' . esc_attr( $li_class ) . '"' . $li_attr . '>';

		$atts  = ' href="' . esc_url( $item->url ) . '" class="' . esc_attr( $a_class ) . '"';
		$atts .= $item->target ? ' target="' . esc_attr( $item->target ) . '"' : '';

		if ( $has_children && 0 === $depth ) {
			$atts .= ' @click.prevent="open = !open" @mouseenter="open = true" :aria-expanded="open ? \'true\' : \'false\'" aria-haspopup="true"';
		}

		$title  = apply_filters( 'the_title', $item->title, $item->ID );
		$output .= '<a' . $atts . '>' . esc_html( $title );

		if ( $has_children && 0 === $depth ) {
			$output .= '<svg class="h-3 w-3 transition-transform" :class="open && \'rotate-180\'" viewBox="0 0 12 12" fill="none" aria-hidden="true"><path d="M2 4.5 6 8.5 10 4.5" stroke="currentColor" stroke-width="1.75"/></svg>';
		}

		$output .= '</a>';
	}

	/**
	 * End an element.
	 *
	 * @param string   $output Output.
	 * @param WP_Post  $item   Menu item.
	 * @param int      $depth  Depth.
	 * @param stdClass $args   Args.
	 */
	public function end_el( &$output, $item, $depth = 0, $args = null ) {
		$output .= '</li>';
	}
}

/**
 * Mobile drawer walker: nested lists with disclosure toggles.
 */
class AGZ_Mobile_Nav_Walker extends Walker_Nav_Menu {

	/**
	 * Start a submenu level.
	 *
	 * @param string   $output Output.
	 * @param int      $depth  Depth.
	 * @param stdClass $args   Args.
	 */
	public function start_lvl( &$output, $depth = 0, $args = null ) {
		$output .= '<ul x-show="open" x-collapse x-cloak class="mt-1 border-l-2 border-stone pl-4">';
	}

	/**
	 * End a submenu level.
	 *
	 * @param string   $output Output.
	 * @param int      $depth  Depth.
	 * @param stdClass $args   Args.
	 */
	public function end_lvl( &$output, $depth = 0, $args = null ) {
		$output .= '</ul>';
	}

	/**
	 * Start an element.
	 *
	 * @param string   $output Output.
	 * @param WP_Post  $item   Menu item.
	 * @param int      $depth  Depth.
	 * @param stdClass $args   Args.
	 * @param int      $id     ID.
	 */
	public function start_el( &$output, $item, $depth = 0, $args = null, $id = 0 ) {
		$has_children = in_array( 'menu-item-has-children', (array) $item->classes, true );
		$title        = apply_filters( 'the_title', $item->title, $item->ID );

		$output .= '<li class="py-1"' . ( $has_children ? ' x-data="{ open: false }"' : '' ) . '>';
		$output .= '<div class="flex items-center justify-between gap-3">';
		$output .= '<a href="' . esc_url( $item->url ) . '" class="font-display text-base font-semibold uppercase tracking-[0.06em] text-ink hover:text-field">' . esc_html( $title ) . '</a>';

		if ( $has_children ) {
			$output .= '<button type="button" @click="open = !open" :aria-expanded="open ? \'true\' : \'false\'" class="grid h-8 w-8 place-items-center border-2 border-ink/15 text-ink" aria-label="' . esc_attr__( 'Toggle submenu', 'shop-agroznet' ) . '"><svg class="h-3.5 w-3.5 transition-transform" :class="open && \'rotate-45\'" viewBox="0 0 14 14" aria-hidden="true"><path d="M7 1v12M1 7h12" stroke="currentColor" stroke-width="2"/></svg></button>';
		}

		$output .= '</div>';
	}

	/**
	 * End an element.
	 *
	 * @param string   $output Output.
	 * @param WP_Post  $item   Menu item.
	 * @param int      $depth  Depth.
	 * @param stdClass $args   Args.
	 */
	public function end_el( &$output, $item, $depth = 0, $args = null ) {
		$output .= '</li>';
	}
}
