<?php
/**
 * WooCommerce integration.
 *
 * Only five templates are overridden in /woocommerce (shop archive, single
 * product, search results, cart, checkout). Everything else stays on plugin
 * defaults and is shaped from here with hooks and from assets/css/theme.css.
 *
 * @package ShopAgroznet
 */

defined( 'ABSPATH' ) || exit;

/* -------------------------------------------------------------------------
 * Page shell — replaces WooCommerce's own wrappers so every WooCommerce page
 * (including the ones we do not override, such as My account) sits inside the
 * theme's header, footer and container.
 * ---------------------------------------------------------------------- */

remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10 );
remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10 );
remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20 );
remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10 );

/**
 * Open the WooCommerce content shell.
 */
function agz_wc_wrapper_start() {
	echo '<main id="main" class="agz-wc-shell mx-auto w-full max-w-shell px-4 pb-24 pt-8 sm:px-6 lg:px-8">';
}
add_action( 'woocommerce_before_main_content', 'agz_wc_wrapper_start', 10 );

/**
 * Close the WooCommerce content shell.
 */
function agz_wc_wrapper_end() {
	echo '</main>';
}
add_action( 'woocommerce_after_main_content', 'agz_wc_wrapper_end', 10 );

/* -------------------------------------------------------------------------
 * Hook adjustments the overridden templates rely on.
 *
 * Each removal exists because the matching template renders that piece itself.
 * The do_action() calls stay in the templates, so anything a plugin adds to
 * these hooks still runs.
 * ---------------------------------------------------------------------- */

// Archive toolbar is rendered by woocommerce/archive-product.php.
remove_action( 'woocommerce_before_shop_loop', 'woocommerce_result_count', 20 );
remove_action( 'woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30 );

// The empty state is rendered by woocommerce/archive-product.php.
remove_action( 'woocommerce_no_products_found', 'wc_no_products_found', 10 );

// Card markup is owned by woocommerce/content-product.php.
remove_action( 'woocommerce_before_shop_loop_item', 'woocommerce_template_loop_product_link_open', 10 );
remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_show_product_loop_sale_flash', 10 );
remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail', 10 );
remove_action( 'woocommerce_shop_loop_item_title', 'woocommerce_template_loop_product_title', 10 );
remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 5 );
remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price', 10 );
remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_product_link_close', 5 );

// Title, price and short description are rendered by content-single-product.php.
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_title', 5 );
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price', 10 );
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_excerpt', 20 );

// Cross-sells get full width beneath the cart instead of the narrow column.
remove_action( 'woocommerce_cart_collaterals', 'woocommerce_cross_sell_display' );

// The empty-cart call to action is rendered by woocommerce/cart/cart-empty.php.
remove_action( 'woocommerce_cart_is_empty', 'wc_empty_cart_message', 10 );

/**
 * Products per row.
 *
 * @return int
 */
function agz_loop_columns() {
	return 3;
}
add_filter( 'loop_shop_columns', 'agz_loop_columns' );

/**
 * Products per page.
 *
 * @return int
 */
function agz_products_per_page() {
	return 12;
}
add_filter( 'loop_shop_per_page', 'agz_products_per_page', 20 );

/**
 * Pagination arrows in the theme's voice.
 *
 * @param array $args Pagination args.
 * @return array
 */
function agz_pagination_args( $args ) {
	$args['prev_text'] = __( 'Previous', 'shop-agroznet' );
	$args['next_text'] = __( 'Next', 'shop-agroznet' );
	$args['type']      = 'list';
	return $args;
}
add_filter( 'woocommerce_pagination_args', 'agz_pagination_args' );

/**
 * Related products: three across, matching the grid.
 *
 * @param array $args Args.
 * @return array
 */
function agz_related_products_args( $args ) {
	$args['posts_per_page'] = 3;
	$args['columns']        = 3;
	return $args;
}
add_filter( 'woocommerce_output_related_products_args', 'agz_related_products_args', 20 );

/* -------------------------------------------------------------------------
 * Buttons and badges
 * ---------------------------------------------------------------------- */

/**
 * Give loop add-to-cart buttons the theme's button classes.
 *
 * @param array $args    Button args.
 * @param mixed $product Product.
 * @return array
 */
function agz_loop_add_to_cart_args( $args, $product ) {
	$args['class'] = str_replace( 'button', '', $args['class'] ) . ' agz-loop-cart ' . agz_btn( 'solid' ) . ' w-full !px-4 !py-2.5';
	return $args;
}
add_filter( 'woocommerce_loop_add_to_cart_args', 'agz_loop_add_to_cart_args', 10, 2 );

/**
 * The sale badge, drawn as a stamped tag.
 *
 * @return string
 */
function agz_sale_flash() {
	return '<span class="agz-sale absolute left-3 top-3 z-10 border-2 border-ink bg-tractor px-2 py-1 font-mono text-[10px] font-semibold uppercase tracking-label text-ink">' . esc_html__( 'Reduced', 'shop-agroznet' ) . '</span>';
}
add_filter( 'woocommerce_sale_flash', 'agz_sale_flash', 10, 1 );

/* -------------------------------------------------------------------------
 * Cart count fragment — keeps the header badge and drawer live after AJAX
 * add-to-cart, without a page reload.
 * ---------------------------------------------------------------------- */

/**
 * Render the header cart button.
 */
function agz_cart_button() {
	$count = WC()->cart ? WC()->cart->get_cart_contents_count() : 0;
	$total = WC()->cart ? WC()->cart->get_cart_subtotal() : '';
	?>
	<a href="<?php echo esc_url( wc_get_cart_url() ); ?>"
	   class="agz-cart-button group relative inline-flex items-center gap-2 border-2 border-ink bg-paper px-3 py-2 transition-transform hover:-translate-y-[2px] hover:shadow-tag-sm"
	   @click.prevent="$dispatch('open-cart')">
		<svg class="h-4 w-4" viewBox="0 0 20 20" fill="none" aria-hidden="true">
			<path d="M2 3h3l2.2 9.4a1.5 1.5 0 0 0 1.46 1.1h6.1a1.5 1.5 0 0 0 1.46-1.14L18 6H6" stroke="currentColor" stroke-width="1.8" stroke-linecap="square"/>
			<circle cx="9" cy="17" r="1.3" fill="currentColor"/><circle cx="15.5" cy="17" r="1.3" fill="currentColor"/>
		</svg>
		<span class="hidden font-mono text-[11px] uppercase tracking-label sm:inline"><?php echo wp_kses_post( $total ); ?></span>
		<span class="grid h-5 min-w-[1.25rem] place-items-center bg-field px-1 font-mono text-[11px] font-semibold text-limewash"><?php echo esc_html( $count ); ?></span>
		<span class="sr-only"><?php esc_html_e( 'Open your order', 'shop-agroznet' ); ?></span>
	</a>
	<?php
}

/**
 * Add the header cart button to the AJAX fragments.
 *
 * @param array $fragments Fragments.
 * @return array
 */
function agz_cart_fragments( $fragments ) {
	ob_start();
	echo '<div class="agz-cart-fragment">';
	agz_cart_button();
	echo '</div>';
	$fragments['div.agz-cart-fragment'] = ob_get_clean();

	ob_start();
	echo '<div class="agz-drawer-fragment">';
	get_template_part( 'template-parts/cart-drawer-contents' );
	echo '</div>';
	$fragments['div.agz-drawer-fragment'] = ob_get_clean();

	return $fragments;
}
add_filter( 'woocommerce_add_to_cart_fragments', 'agz_cart_fragments' );

/* -------------------------------------------------------------------------
 * Small refinements to templates we deliberately do not override
 * ---------------------------------------------------------------------- */

/**
 * Move the single-product rating next to the title rather than above the price.
 */
function agz_reorder_single_summary() {
	remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40 );
	add_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta', 55 );
}
add_action( 'wp', 'agz_reorder_single_summary' );

/**
 * Number of thumbnail columns in the gallery.
 *
 * @return int
 */
function agz_gallery_thumbnail_columns() {
	return 5;
}
add_filter( 'woocommerce_product_thumbnails_columns', 'agz_gallery_thumbnail_columns' );

/**
 * Checkout: stack fields in a predictable two-column grid via CSS classes.
 *
 * @param array $fields Fields.
 * @return array
 */
function agz_checkout_field_classes( $fields ) {
	foreach ( $fields as $section => $group ) {
		foreach ( $group as $key => $field ) {
			$fields[ $section ][ $key ]['input_class'][] = 'agz-input';
			$fields[ $section ][ $key ]['label_class'][] = 'agz-label';
		}
	}
	return $fields;
}
add_filter( 'woocommerce_checkout_fields', 'agz_checkout_field_classes' );

/**
 * Coupon field placeholder copy.
 *
 * @param string $text Text.
 * @return string
 */
function agz_coupon_text( $text ) {
	return __( 'Have a trade code?', 'shop-agroznet' );
}
add_filter( 'woocommerce_checkout_coupon_message', 'agz_coupon_text' );

/**
 * Continue-shopping return URL points at the shop, not the referrer.
 *
 * @return string
 */
function agz_return_to_shop_url() {
	return wc_get_page_permalink( 'shop' );
}
add_filter( 'woocommerce_return_to_shop_redirect', 'agz_return_to_shop_url' );

/**
 * Stock status wording used by the product card and single product page.
 *
 * @param WC_Product $product Product.
 * @return array{label:string,tone:string}
 */
function agz_stock_state( $product ) {
	if ( ! $product ) {
		return array( 'label' => '', 'tone' => '' );
	}

	if ( ! $product->is_in_stock() ) {
		return array( 'label' => __( 'Out of stock', 'shop-agroznet' ), 'tone' => 'text-clay' );
	}

	if ( $product->managing_stock() && $product->get_stock_quantity() !== null && $product->get_stock_quantity() <= 5 ) {
		return array(
			/* translators: %d: units remaining. */
			'label' => sprintf( _n( '%d left in the depot', '%d left in the depot', $product->get_stock_quantity(), 'shop-agroznet' ), $product->get_stock_quantity() ),
			'tone'  => 'text-clay',
		);
	}

	return array( 'label' => __( 'In stock', 'shop-agroznet' ), 'tone' => 'text-field' );
}
