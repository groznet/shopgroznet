<?php
/**
 * Template helpers used across the theme.
 *
 * @package ShopAgroznet
 */

defined( 'ABSPATH' ) || exit;

/**
 * The ticked rule that heads every section — the "row marker".
 *
 * @param string $label   Mono eyebrow label.
 * @param string $variant light|dark.
 */
function agz_row_marker( $label = '', $variant = 'light' ) {
	$line = 'dark' === $variant ? 'bg-limewash/25' : 'bg-ink/20';
	$text = 'dark' === $variant ? 'text-limewash/60' : 'text-ink/55';
	?>
	<div class="flex items-center gap-3" aria-hidden="<?php echo $label ? 'false' : 'true'; ?>">
		<span class="block h-3 w-[2px] <?php echo esc_attr( $line ); ?>"></span>
		<span class="block h-[2px] w-6 <?php echo esc_attr( $line ); ?>"></span>
		<?php if ( $label ) : ?>
			<span class="font-mono text-[11px] uppercase tracking-label <?php echo esc_attr( $text ); ?>"><?php echo esc_html( $label ); ?></span>
		<?php endif; ?>
		<span class="block h-[2px] flex-1 <?php echo esc_attr( $line ); ?>"></span>
		<span class="block h-3 w-[2px] <?php echo esc_attr( $line ); ?>"></span>
	</div>
	<?php
}

/**
 * A short plot-style code for a post or product. Uses the SKU when there is one.
 *
 * @param int|WP_Post|null $post_id Post.
 * @return string
 */
function agz_plot_code( $post_id = null ) {
	$post_id = $post_id ? ( $post_id instanceof WP_Post ? $post_id->ID : (int) $post_id ) : get_the_ID();

	if ( function_exists( 'wc_get_product' ) ) {
		$product = wc_get_product( $post_id );
		if ( $product && $product->get_sku() ) {
			return strtoupper( $product->get_sku() );
		}
	}

	return sprintf( 'AGZ-%04d', $post_id % 10000 );
}

/**
 * Section heading in the display face.
 *
 * @param string $text  Heading text.
 * @param string $tag   Heading element.
 * @param string $extra Extra classes.
 */
function agz_heading( $text, $tag = 'h2', $extra = '' ) {
	printf(
		'<%1$s class="font-display font-extrabold uppercase tracking-stencil leading-[0.95] %2$s">%3$s</%1$s>',
		esc_attr( $tag ),
		esc_attr( $extra ? $extra : 'text-3xl sm:text-4xl' ),
		esc_html( $text )
	);
}

/**
 * Primary button classes. Hard offset shadow, square corners.
 *
 * @param string $style solid|outline|ghost|accent.
 * @return string
 */
function agz_btn( $style = 'solid' ) {
	$base = 'agz-btn inline-flex items-center justify-center gap-2 border-2 border-ink px-5 py-3 font-display text-[13px] font-bold uppercase tracking-[0.1em] transition-transform duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-field';

	$styles = array(
		'solid'   => 'bg-field text-limewash shadow-tag hover:-translate-x-[2px] hover:-translate-y-[2px] hover:shadow-tag-lift active:translate-x-0 active:translate-y-0 active:shadow-none',
		'accent'  => 'bg-tractor text-ink shadow-tag hover:-translate-x-[2px] hover:-translate-y-[2px] hover:shadow-tag-lift active:translate-x-0 active:translate-y-0 active:shadow-none',
		'outline' => 'bg-transparent text-ink hover:bg-ink hover:text-limewash',
		'ghost'   => 'border-transparent px-2 py-1 text-ink hover:text-field',
	);

	return $base . ' ' . ( $styles[ $style ] ?? $styles['solid'] );
}

/**
 * Breadcrumb trail rendered in the theme's own style.
 */
function agz_breadcrumb() {
	$crumbs = array();
	$crumbs[] = array( 'label' => __( 'Home', 'shop-agroznet' ), 'url' => home_url( '/' ) );

	if ( function_exists( 'is_woocommerce' ) && ( is_woocommerce() || is_cart() || is_checkout() ) ) {
		$shop_id = wc_get_page_id( 'shop' );
		if ( $shop_id > 0 ) {
			$crumbs[] = array( 'label' => get_the_title( $shop_id ), 'url' => get_permalink( $shop_id ) );
		}
	}

	if ( is_singular( 'product' ) ) {
		$terms = get_the_terms( get_the_ID(), 'product_cat' );
		if ( $terms && ! is_wp_error( $terms ) ) {
			$term     = array_shift( $terms );
			$crumbs[] = array( 'label' => $term->name, 'url' => get_term_link( $term ) );
		}
		$crumbs[] = array( 'label' => get_the_title(), 'url' => '' );
	} elseif ( is_product_category() || is_product_tag() ) {
		$crumbs[] = array( 'label' => single_term_title( '', false ), 'url' => '' );
	} elseif ( is_search() ) {
		$crumbs[] = array( 'label' => __( 'Search results', 'shop-agroznet' ), 'url' => '' );
	} elseif ( is_singular() || is_page() ) {
		$crumbs[] = array( 'label' => get_the_title(), 'url' => '' );
	}

	echo '<nav aria-label="' . esc_attr__( 'Breadcrumb', 'shop-agroznet' ) . '" class="font-mono text-[11px] uppercase tracking-label text-ink/55">';
	$last = count( $crumbs ) - 1;
	foreach ( $crumbs as $i => $crumb ) {
		if ( $crumb['url'] && $i !== $last ) {
			printf( '<a href="%s" class="hover:text-field">%s</a>', esc_url( $crumb['url'] ), esc_html( wp_trim_words( $crumb['label'], 6, '' ) ) );
		} else {
			printf( '<span class="text-ink">%s</span>', esc_html( wp_trim_words( $crumb['label'], 8, '' ) ) );
		}
		if ( $i !== $last ) {
			echo '<span class="mx-2 text-ink/30">/</span>';
		}
	}
	echo '</nav>';
}

/**
 * Post meta line for the journal.
 */
function agz_post_meta() {
	printf(
		'<div class="font-mono text-[11px] uppercase tracking-label text-ink/55">%1$s <span class="mx-2 text-ink/30">/</span> %2$s</div>',
		esc_html( get_the_date( 'd M Y' ) ),
		esc_html( get_the_author() )
	);
}
