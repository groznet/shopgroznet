<?php
/**
 * Theme setup.
 *
 * @package ShopAgroznet
 */

defined( 'ABSPATH' ) || exit;

/**
 * Register theme supports.
 */
function agz_setup() {
	load_theme_textdomain( 'shop-agroznet', AGZ_DIR . '/languages' );

	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'customize-selective-refresh-widgets' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'editor-styles' );
	add_theme_support(
		'html5',
		array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script', 'navigation-widgets' )
	);
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 64,
			'width'       => 240,
			'flex-width'  => true,
			'flex-height' => true,
		)
	);

	// WooCommerce. Gallery features are opt-in and used by the single product override.
	add_theme_support(
		'woocommerce',
		array(
			'thumbnail_image_width' => 480,
			'single_image_width'    => 1200,
			'product_grid'          => array(
				'default_columns' => 3,
				'default_rows'    => 4,
				'min_columns'     => 2,
				'max_columns'     => 4,
			),
		)
	);
	add_theme_support( 'wc-product-gallery-zoom' );
	add_theme_support( 'wc-product-gallery-lightbox' );
	add_theme_support( 'wc-product-gallery-slider' );

	register_nav_menus(
		array(
			'primary'    => __( 'Primary menu', 'shop-agroznet' ),
			'departments' => __( 'Shop departments', 'shop-agroznet' ),
			'footer'     => __( 'Footer links', 'shop-agroznet' ),
			'legal'      => __( 'Legal links', 'shop-agroznet' ),
		)
	);

	// Image size used by the field-tag product card.
	add_image_size( 'agz-card', 700, 700, true );
}
add_action( 'after_setup_theme', 'agz_setup' );

/**
 * Content width.
 */
function agz_content_width() {
	$GLOBALS['content_width'] = 1200;
}
add_action( 'after_setup_theme', 'agz_content_width', 0 );

/**
 * Widget areas.
 */
function agz_widgets_init() {
	register_sidebar(
		array(
			'name'          => __( 'Shop sidebar', 'shop-agroznet' ),
			'id'            => 'shop-sidebar',
			'description'   => __( 'Filters and links shown beside the shop archive.', 'shop-agroznet' ),
			'before_widget' => '<section id="%1$s" class="agz-widget %2$s border-b border-stone pb-6 mb-6">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="font-mono text-[11px] uppercase tracking-[0.18em] text-ink/60 mb-3">',
			'after_title'   => '</h2>',
		)
	);

	for ( $i = 1; $i <= 3; $i++ ) {
		register_sidebar(
			array(
				/* translators: %d: footer column number. */
				'name'          => sprintf( __( 'Footer column %d', 'shop-agroznet' ), $i ),
				'id'            => 'footer-' . $i,
				'before_widget' => '<section id="%1$s" class="agz-widget %2$s mb-8">',
				'after_widget'  => '</section>',
				'before_title'  => '<h2 class="font-mono text-[11px] uppercase tracking-[0.18em] text-limewash/50 mb-4">',
				'after_title'   => '</h2>',
			)
		);
	}
}
add_action( 'widgets_init', 'agz_widgets_init' );

/**
 * Body classes used by the design system.
 *
 * @param array $classes Existing classes.
 * @return array
 */
function agz_body_class( $classes ) {
	$classes[] = 'bg-limewash';
	$classes[] = 'text-ink';
	$classes[] = 'font-body';
	$classes[] = 'antialiased';

	if ( function_exists( 'is_woocommerce' ) && ( is_woocommerce() || is_cart() || is_checkout() || is_account_page() ) ) {
		$classes[] = 'agz-shop';
	}

	return $classes;
}
add_filter( 'body_class', 'agz_body_class' );

/**
 * Excerpt tail.
 *
 * @return string
 */
function agz_excerpt_more() {
	return '&nbsp;&hellip;';
}
add_filter( 'excerpt_more', 'agz_excerpt_more' );
