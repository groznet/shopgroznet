<?php
/**
 * Non-product archives.
 *
 * @package ShopAgroznet
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>

<main id="main" class="mx-auto w-full max-w-shell px-4 pb-24 pt-10 sm:px-6 lg:px-8">
	<header class="mb-12">
		<?php agz_row_marker( __( 'Archive', 'shop-agroznet' ) ); ?>
		<h1 class="mt-5 font-display text-4xl font-extrabold uppercase leading-[0.95] tracking-stencil sm:text-5xl">
			<?php the_archive_title(); ?>
		</h1>
		<?php the_archive_description( '<div class="mt-4 max-w-xl text-base text-ink/70">', '</div>' ); ?>
	</header>

	<?php if ( have_posts() ) : ?>
		<div class="grid gap-px bg-stone sm:grid-cols-2 lg:grid-cols-3">
			<?php
			while ( have_posts() ) :
				the_post();
				get_template_part( 'template-parts/content', get_post_type() );
			endwhile;
			?>
		</div>
		<div class="agz-pagination mt-12"><?php the_posts_pagination( array( 'mid_size' => 1 ) ); ?></div>
	<?php else : ?>
		<p class="border-2 border-ink bg-paper p-8 text-center font-display uppercase tracking-stencil"><?php esc_html_e( 'Nothing filed under this heading yet', 'shop-agroznet' ); ?></p>
	<?php endif; ?>
</main>

<?php
get_footer();
