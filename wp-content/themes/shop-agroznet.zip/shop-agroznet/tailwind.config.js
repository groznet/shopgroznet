/**
 * Tailwind configuration for Shop Agroznet.
 *
 * Mirrors agz_design_tokens() in inc/assets.php, which feeds the no-build
 * browser runtime. Change a token in one place and change it in the other.
 */
module.exports = {
	content: [
		'./*.php',
		'./inc/**/*.php',
		'./template-parts/**/*.php',
		'./woocommerce/**/*.php',
		'./assets/js/**/*.js',
	],
	theme: {
		extend: {
			colors: {
				ink: '#16261C',
				field: '#1F6F43',
				'field-700': '#175634',
				tractor: '#F2C230',
				clay: '#B4532A',
				limewash: '#F1F3EC',
				paper: '#FBFCF8',
			},
			fontFamily: {
				display: ['Archivo', 'Arial Narrow', 'system-ui', 'sans-serif'],
				body: ['Public Sans', 'system-ui', 'sans-serif'],
				mono: ['IBM Plex Mono', 'ui-monospace', 'monospace'],
			},
			letterSpacing: {
				stencil: '-0.02em',
				label: '0.18em',
			},
			boxShadow: {
				tag: '4px 4px 0 0 #16261C',
				'tag-sm': '3px 3px 0 0 #16261C',
				'tag-lift': '6px 6px 0 0 #16261C',
				field: '4px 4px 0 0 #1F6F43',
			},
			maxWidth: {
				shell: '84rem',
			},
		},
	},
	corePlugins: {
		// The design language is square by default; radius is opt-in per element.
		preflight: true,
	},
	plugins: [],
};
