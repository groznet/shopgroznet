<?php
/**
 * Checkout form.
 *
 * Override of woocommerce/templates/checkout/form-checkout.php. Two columns
 * with a sticky order review; the numbered markers are kept because checkout
 * genuinely is a sequence. Every WooCommerce hook and field name is preserved.
 *
 * @package ShopAgroznet
 * @version 9.4.0
 */

defined( 'ABSPATH' ) || exit;

/** @var WC_Checkout $checkout */
$checkout = WC()->checkout();

do_action( 'woocommerce_before_checkout_form', $checkout );

// Registration may be required and the user not logged in.
if ( ! $checkout->is_registration_enabled() && $checkout->is_registration_required() && ! is_user_logged_in() ) {
	echo '<div class="border-2 border-ink bg-paper p-8 text-center">';
	echo '<p class="font-display text-lg font-bold uppercase tracking-stencil">' . esc_html( apply_filters( 'woocommerce_checkout_must_be_logged_in_message', __( 'Sign in to your trade account to check out.', 'shop-agroznet' ) ) ) . '</p>';
	echo '<a class="' . esc_attr( agz_btn( 'solid' ) ) . ' mt-6" href="' . esc_url( wc_get_page_permalink( 'myaccount' ) ) . '">' . esc_html__( 'Sign in', 'shop-agroznet' ) . '</a>';
	echo '</div>';
	return;
}
?>

<div class="agz-checkout">

	<header class="border-b-2 border-ink pb-8">
		<?php agz_breadcrumb(); ?>
		<h1 class="mt-5 font-display text-4xl font-extrabold uppercase leading-[0.95] tracking-stencil sm:text-6xl">
			<?php esc_html_e( 'Checkout', 'shop-agroznet' ); ?>
		</h1>
		<p class="mt-4 max-w-xl text-sm text-ink/70">
			<?php esc_html_e( 'Three steps. Delivery is priced from your postcode; pallet freight is confirmed by the depot before dispatch.', 'shop-agroznet' ); ?>
		</p>
	</header>

	<form name="checkout" method="post" class="checkout woocommerce-checkout mt-10"
		action="<?php echo esc_url( wc_get_checkout_url() ); ?>" enctype="multipart/form-data"
		aria-label="<?php echo esc_attr__( 'Checkout', 'woocommerce' ); ?>">

		<div class="grid gap-12 lg:grid-cols-[1fr_24rem] lg:gap-16 lg:items-start">

			<div class="min-w-0 space-y-14">
				<?php if ( $checkout->get_checkout_fields() ) : ?>

					<?php do_action( 'woocommerce_checkout_before_customer_details' ); ?>

					<div class="col2-set" id="customer_details">
						<section class="col-1">
							<div class="mb-6 flex items-baseline gap-4">
								<span class="font-mono text-[11px] uppercase tracking-label text-ink/40">01</span>
								<?php agz_heading( __( 'Your details', 'shop-agroznet' ), 'h2', 'text-2xl' ); ?>
							</div>
							<div class="agz-fields border-2 border-ink bg-paper p-6 sm:p-8">
								<?php do_action( 'woocommerce_checkout_billing' ); ?>
							</div>
						</section>

						<section class="col-2 mt-14">
							<div class="mb-6 flex items-baseline gap-4">
								<span class="font-mono text-[11px] uppercase tracking-label text-ink/40">02</span>
								<?php agz_heading( __( 'Delivery', 'shop-agroznet' ), 'h2', 'text-2xl' ); ?>
							</div>
							<div class="agz-fields border-2 border-ink bg-paper p-6 sm:p-8">
								<?php do_action( 'woocommerce_checkout_shipping' ); ?>
							</div>
						</section>
					</div>

					<?php do_action( 'woocommerce_checkout_after_customer_details' ); ?>

				<?php endif; ?>
			</div>

			<!-- Order review ------------------------------------------------ -->
			<aside class="lg:sticky lg:top-32">
				<?php do_action( 'woocommerce_checkout_before_order_review_heading' ); ?>

				<div class="mb-6 flex items-baseline gap-4">
					<span class="font-mono text-[11px] uppercase tracking-label text-ink/40">03</span>
					<h2 id="order_review_heading" class="font-display text-2xl font-extrabold uppercase tracking-stencil leading-[0.95]">
						<?php esc_html_e( 'Review and pay', 'shop-agroznet' ); ?>
					</h2>
				</div>

				<?php do_action( 'woocommerce_checkout_before_order_review' ); ?>

				<div id="order_review" class="woocommerce-checkout-review-order agz-review border-2 border-ink bg-paper p-6 shadow-tag">
					<?php do_action( 'woocommerce_checkout_order_review' ); ?>
				</div>

				<?php do_action( 'woocommerce_checkout_after_order_review' ); ?>

				<ul class="mt-6 space-y-2 font-mono text-[10px] uppercase tracking-label text-ink/45">
					<li class="flex gap-2"><span class="text-field" aria-hidden="true">&#10003;</span><?php esc_html_e( 'Payment handled on an encrypted connection', 'shop-agroznet' ); ?></li>
					<li class="flex gap-2"><span class="text-field" aria-hidden="true">&#10003;</span><?php esc_html_e( 'Order confirmation emailed within minutes', 'shop-agroznet' ); ?></li>
					<li class="flex gap-2"><span class="text-field" aria-hidden="true">&#10003;</span><?php esc_html_e( 'Depot will call if anything needs confirming', 'shop-agroznet' ); ?></li>
				</ul>
			</aside>
		</div>
	</form>
</div>

<?php do_action( 'woocommerce_after_checkout_form', $checkout ); ?>
