<?php
/**
 * Product archive — shop, product categories, product tags and product search.
 *
 * Override of woocommerce/templates/archive-product.php.
 *
 * @package ShopAgroznet
 * @version 8.6.0
 */

defined( 'ABSPATH' ) || exit;

get_header( 'shop' );

/**
 * Opens the theme's <main> wrapper (see inc/woocommerce.php).
 */
do_action( 'woocommerce_before_main_content' );

$agz_is_search   = is_search();
$agz_total       = (int) wc_get_loop_prop( 'total' );
$agz_description = ! $agz_is_search ? do_shortcode( term_description() ) : '';
$agz_has_sidebar = is_active_sidebar( 'shop-sidebar' );
?>

<!-- Archive head ---------------------------------------------------------- -->
<header class="border-b-2 border-ink pb-8">
	<?php agz_breadcrumb(); ?>

	<div class="mt-5 flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
		<div class="max-w-2xl">
			<?php if ( apply_filters( 'woocommerce_show_page_title', true ) ) : ?>
				<h1 class="font-display text-4xl font-extrabold uppercase leading-[0.95] tracking-stencil sm:text-6xl">
					<?php
					if ( $agz_is_search ) {
						printf(
							/* translators: %s: search term. */
							esc_html__( 'Results for “%s”', 'shop-agroznet' ),
							esc_html( get_search_query() )
						);
					} else {
						woocommerce_page_title();
					}
					?>
				</h1>
			<?php endif; ?>

			<?php if ( $agz_description ) : ?>
				<div class="agz-prose mt-4 text-base text-ink/70"><?php echo wp_kses_post( $agz_description ); ?></div>
			<?php elseif ( $agz_is_search ) : ?>
				<p class="mt-4 text-base text-ink/70">
					<?php esc_html_e( 'Matches from the catalogue. Search by product name, variety or SKU.', 'shop-agroznet' ); ?>
				</p>
			<?php endif; ?>
		</div>

		<!-- Stock counter, in the mono utility face -->
		<dl class="flex shrink-0 gap-px border-2 border-ink bg-ink font-mono text-[11px] uppercase tracking-label">
			<div class="bg-limewash px-4 py-3">
				<dt class="text-ink/50"><?php esc_html_e( 'Lines', 'shop-agroznet' ); ?></dt>
				<dd class="mt-1 text-base font-semibold not-italic text-ink"><?php echo esc_html( $agz_total ); ?></dd>
			</div>
			<div class="bg-limewash px-4 py-3">
				<dt class="text-ink/50"><?php esc_html_e( 'Showing', 'shop-agroznet' ); ?></dt>
				<dd class="mt-1 text-base font-semibold not-italic text-ink"><?php echo esc_html( (int) wc_get_loop_prop( 'per_page' ) ); ?></dd>
			</div>
		</dl>
	</div>

	<?php
	// Keeps plugin output (category images, Yoast, filters) working.
	do_action( 'woocommerce_archive_description' );
	?>
</header>

<?php if ( woocommerce_product_loop() ) : ?>

	<div class="mt-10 grid gap-10 <?php echo $agz_has_sidebar ? 'lg:grid-cols-[16rem_1fr]' : ''; ?>"
		x-data="agzArchive()">

		<?php if ( $agz_has_sidebar ) : ?>
			<!-- Filter rail ------------------------------------------------- -->
			<div class="lg:sticky lg:top-32 lg:self-start">
				<button type="button" @click="filters = !filters"
					class="<?php echo esc_attr( agz_btn( 'outline' ) ); ?> w-full lg:hidden"
					:aria-expanded="filters ? 'true' : 'false'">
					<?php esc_html_e( 'Filters', 'shop-agroznet' ); ?>
				</button>

				<aside class="mt-4 lg:mt-0" :class="filters ? 'block' : 'hidden lg:block'"
					aria-label="<?php esc_attr_e( 'Product filters', 'shop-agroznet' ); ?>">
					<?php agz_row_marker( __( 'Narrow it down', 'shop-agroznet' ) ); ?>
					<div class="agz-shop-sidebar mt-5">
						<?php dynamic_sidebar( 'shop-sidebar' ); ?>
					</div>
				</aside>
			</div>
		<?php endif; ?>

		<div class="min-w-0">

			<!-- Toolbar ------------------------------------------------------ -->
			<div class="mb-8 flex flex-col gap-4 border-y-2 border-ink py-4 sm:flex-row sm:items-center sm:justify-between">
				<div class="agz-result-count font-mono text-[11px] uppercase tracking-label text-ink/60">
					<?php woocommerce_result_count(); ?>
				</div>

				<div class="flex items-center gap-3">
					<!-- Grid / list toggle -->
					<div class="hidden items-center gap-px border-2 border-ink bg-ink sm:flex" role="group" aria-label="<?php esc_attr_e( 'Layout', 'shop-agroznet' ); ?>">
						<button type="button" @click="setView('grid')" :class="view === 'grid' ? 'bg-ink text-limewash' : 'bg-limewash text-ink'" class="px-2.5 py-2" aria-label="<?php esc_attr_e( 'Grid layout', 'shop-agroznet' ); ?>">
							<svg class="h-4 w-4" viewBox="0 0 16 16" aria-hidden="true"><path d="M2 2h5v5H2zM9 2h5v5H9zM2 9h5v5H2zM9 9h5v5H9z" fill="currentColor"/></svg>
						</button>
						<button type="button" @click="setView('list')" :class="view === 'list' ? 'bg-ink text-limewash' : 'bg-limewash text-ink'" class="px-2.5 py-2" aria-label="<?php esc_attr_e( 'List layout', 'shop-agroznet' ); ?>">
							<svg class="h-4 w-4" viewBox="0 0 16 16" aria-hidden="true"><path d="M2 3h12v2H2zM2 7h12v2H2zM2 11h12v2H2z" fill="currentColor"/></svg>
						</button>
					</div>

					<!-- Ordering -->
					<form class="agz-ordering flex items-center gap-2" method="get">
						<label for="agz-orderby" class="font-mono text-[11px] uppercase tracking-label text-ink/60">
							<?php esc_html_e( 'Sort', 'shop-agroznet' ); ?>
						</label>
						<select name="orderby" id="agz-orderby"
							class="border-2 border-ink bg-paper px-3 py-2 font-mono text-[11px] uppercase tracking-label focus:outline-none focus:ring-2 focus:ring-field focus:ring-offset-2">
							<?php
							$agz_catalog_orderby = apply_filters(
								'woocommerce_catalog_orderby',
								array(
									'menu_order' => __( 'Depot order', 'shop-agroznet' ),
									'popularity' => __( 'Most bought', 'shop-agroznet' ),
									'rating'     => __( 'Best rated', 'shop-agroznet' ),
									'date'       => __( 'Newest in', 'shop-agroznet' ),
									'price'      => __( 'Price, low first', 'shop-agroznet' ),
									'price-desc' => __( 'Price, high first', 'shop-agroznet' ),
								)
							);

							$agz_orderby = wc_get_loop_prop( 'is_search' ) ? 'relevance' : get_option( 'woocommerce_default_catalog_orderby', 'menu_order' );
							$agz_orderby = isset( $_GET['orderby'] ) ? wc_clean( wp_unslash( $_GET['orderby'] ) ) : $agz_orderby; // phpcs:ignore WordPress.Security.NonceVerification

							foreach ( $agz_catalog_orderby as $agz_id => $agz_name ) {
								printf( '<option value="%s" %s>%s</option>', esc_attr( $agz_id ), selected( $agz_orderby, $agz_id, false ), esc_html( $agz_name ) );
							}
							?>
						</select>
						<noscript><button type="submit" class="<?php echo esc_attr( agz_btn( 'outline' ) ); ?> !px-3 !py-2"><?php esc_html_e( 'Apply', 'shop-agroznet' ); ?></button></noscript>
						<?php wc_query_string_form_fields( null, array( 'orderby', 'submit', 'paged', 'product-page' ) ); ?>
					</form>
				</div>
			</div>

			<?php do_action( 'woocommerce_before_shop_loop' ); ?>

			<!-- Product grid ------------------------------------------------- -->
			<ul class="products grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3"
				:class="view === 'list' && 'agz-list-view !grid-cols-1'">
				<?php
				while ( have_posts() ) {
					the_post();

					do_action( 'woocommerce_shop_loop' );

					wc_get_template_part( 'content', 'product' );
				}
				?>
			</ul>

			<div class="agz-pagination mt-12">
				<?php do_action( 'woocommerce_after_shop_loop' ); ?>
			</div>
		</div>
	</div>

<?php else : ?>

	<!-- Empty state ------------------------------------------------------- -->
	<div class="mt-12 border-2 border-ink bg-paper p-10 text-center sm:p-16">
		<p class="font-mono text-[11px] uppercase tracking-label text-clay"><?php esc_html_e( 'Nothing matched', 'shop-agroznet' ); ?></p>
		<h2 class="mx-auto mt-4 max-w-xl font-display text-2xl font-extrabold uppercase leading-tight tracking-stencil sm:text-4xl">
			<?php
			if ( $agz_is_search ) {
				esc_html_e( 'No products under that name', 'shop-agroznet' );
			} else {
				esc_html_e( 'This department is empty', 'shop-agroznet' );
			}
			?>
		</h2>
		<p class="mx-auto mt-4 max-w-md text-sm leading-relaxed text-ink/70">
			<?php esc_html_e( 'Try a broader term or a SKU, or call the depot and we will source it for you.', 'shop-agroznet' ); ?>
		</p>

		<div class="mx-auto mt-8 max-w-md"><?php get_search_form(); ?></div>

		<a href="<?php echo esc_url( wc_get_page_permalink( 'shop' ) ); ?>" class="<?php echo esc_attr( agz_btn( 'solid' ) ); ?> mt-8">
			<?php esc_html_e( 'Back to the full catalogue', 'shop-agroznet' ); ?>
		</a>

		<?php
		// Keeps plugin messaging on this state.
		do_action( 'woocommerce_no_products_found' );
		?>
	</div>

<?php endif; ?>

<?php
do_action( 'woocommerce_after_main_content' );

get_footer( 'shop' );
