<?php
/**
 * Single product page.
 *
 * Override of woocommerce/templates/single-product.php.
 *
 * @package ShopAgroznet
 * @version 1.6.4
 */

defined( 'ABSPATH' ) || exit;

get_header( 'shop' );

/**
 * Opens the theme's <main> wrapper (see inc/woocommerce.php).
 */
do_action( 'woocommerce_before_main_content' );

while ( have_posts() ) {
	the_post();

	wc_get_template_part( 'content', 'single-product' );
}

do_action( 'woocommerce_after_main_content' );

get_footer( 'shop' );
