<?php
/**
 * Product card in the loop — the "field tag".
 *
 * Override of woocommerce/templates/content-product.php. Part of the shop
 * archive override: the archive supplies the grid, this supplies each cell.
 *
 * @package ShopAgroznet
 * @version 3.6.0
 */

defined( 'ABSPATH' ) || exit;

global $product;

if ( empty( $product ) || ! $product->is_visible() ) {
	return;
}

$agz_stock  = agz_stock_state( $product );
$agz_cats   = wc_get_product_category_list( $product->get_id(), ', ' );
$agz_rating = $product->get_average_rating();
?>
<li <?php wc_product_class( 'agz-card group relative flex flex-col border-2 border-ink bg-paper transition-all duration-200 hover:-translate-y-[3px] hover:shadow-tag', $product ); ?>>

	<?php
	/**
	 * Hook: woocommerce_before_shop_loop_item.
	 * Default link open/close callbacks are unhooked in inc/woocommerce.php so
	 * this card can own its markup; third-party callbacks still fire.
	 */
	do_action( 'woocommerce_before_shop_loop_item' );
	?>

	<!-- Media -->
	<div class="relative overflow-hidden border-b-2 border-ink bg-limewash">
		<?php
		woocommerce_show_product_loop_sale_flash();

		/**
		 * Hook: woocommerce_before_shop_loop_item_title.
		 */
		do_action( 'woocommerce_before_shop_loop_item_title' );
		?>

		<!-- Punched hang-tag hole: the recurring mark of this theme -->
		<span class="pointer-events-none absolute right-3 top-3 z-10 h-3.5 w-3.5 rounded-full border-2 border-ink bg-limewash transition-colors group-hover:bg-tractor" aria-hidden="true"></span>

		<a href="<?php the_permalink(); ?>" class="block focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-field" tabindex="-1" aria-hidden="true">
			<?php
			echo wp_kses_post(
				$product->get_image(
					'agz-card',
					array( 'class' => 'aspect-square w-full object-cover transition-transform duration-500 group-hover:scale-[1.04]' )
				)
			);
			?>
		</a>

		<?php if ( ! $product->is_in_stock() ) : ?>
			<span class="absolute inset-x-0 bottom-0 bg-ink/85 px-3 py-1.5 text-center font-mono text-[10px] uppercase tracking-label text-limewash">
				<?php esc_html_e( 'Out of stock', 'shop-agroznet' ); ?>
			</span>
		<?php endif; ?>
	</div>

	<!-- Tag body -->
	<div class="flex flex-1 flex-col p-5">

		<div class="flex items-start justify-between gap-3 font-mono text-[10px] uppercase tracking-label text-ink/50">
			<span class="line-clamp-1"><?php echo $agz_cats ? wp_strip_all_tags( $agz_cats ) : esc_html__( 'Uncategorised', 'shop-agroznet' ); ?></span>
			<span class="shrink-0"><?php echo esc_html( agz_plot_code( $product->get_id() ) ); ?></span>
		</div>

		<h2 class="mt-2 font-display text-base font-bold uppercase leading-tight tracking-[0.02em]">
			<a href="<?php the_permalink(); ?>" class="after:absolute after:inset-0 after:content-[''] hover:text-field">
				<?php echo esc_html( $product->get_name() ); ?>
			</a>
		</h2>

		<?php
		/**
		 * Hook: woocommerce_shop_loop_item_title — kept for plugins.
		 */
		do_action( 'woocommerce_shop_loop_item_title' );
		?>

		<p class="agz-card-excerpt mt-2 hidden text-sm leading-relaxed text-ink/65">
			<?php echo esc_html( wp_trim_words( $product->get_short_description(), 26 ) ); ?>
		</p>

		<?php if ( $agz_rating > 0 ) : ?>
			<p class="mt-2 font-mono text-[10px] uppercase tracking-label text-ink/50">
				<?php
				printf(
					/* translators: 1: rating out of five, 2: review count. */
					esc_html__( 'Rated %1$s / 5 · %2$d reviews', 'shop-agroznet' ),
					esc_html( number_format_i18n( (float) $agz_rating, 1 ) ),
					(int) $product->get_review_count()
				);
				?>
			</p>
		<?php endif; ?>

		<div class="mt-auto pt-5">
			<div class="flex items-end justify-between gap-3 border-t-2 border-dashed border-ink/20 pt-4">
				<span class="agz-price font-mono text-lg font-semibold leading-none text-ink">
					<?php echo wp_kses_post( $product->get_price_html() ); ?>
				</span>
				<?php if ( $agz_stock['label'] ) : ?>
					<span class="font-mono text-[10px] uppercase tracking-label <?php echo esc_attr( $agz_stock['tone'] ); ?>">
						<?php echo esc_html( $agz_stock['label'] ); ?>
					</span>
				<?php endif; ?>
			</div>

			<?php
			/**
			 * Hook: woocommerce_after_shop_loop_item_title.
			 */
			do_action( 'woocommerce_after_shop_loop_item_title' );
			?>

			<div class="agz-card-action relative z-10 mt-4">
				<?php
				/**
				 * Hook: woocommerce_after_shop_loop_item — renders add to cart.
				 */
				do_action( 'woocommerce_after_shop_loop_item' );
				?>
			</div>
		</div>
	</div>
</li>
