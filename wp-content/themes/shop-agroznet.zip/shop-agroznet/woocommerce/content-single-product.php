<?php
/**
 * Single product layout — spec-sheet arrangement.
 *
 * Override of woocommerce/templates/content-single-product.php. Part of the
 * single product override: single-product.php is the shell, this is the layout.
 *
 * The title, price and short description are rendered here directly; their
 * default summary hooks are removed in inc/woocommerce.php, so the remaining
 * summary callbacks (rating, add to cart, meta, sharing) still fire in order.
 *
 * @package ShopAgroznet
 * @version 3.6.0
 */

defined( 'ABSPATH' ) || exit;

global $product;

/**
 * Hook: woocommerce_before_single_product.
 */
do_action( 'woocommerce_before_single_product' );

if ( post_password_required() ) {
	echo get_the_password_form(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	return;
}

$agz_stock = agz_stock_state( $product );
$agz_attrs = $product->get_attributes();
?>
<div id="product-<?php the_ID(); ?>" <?php wc_product_class( 'agz-single', $product ); ?>>

	<div class="pb-8"><?php agz_breadcrumb(); ?></div>

	<div class="grid gap-10 lg:grid-cols-[1.05fr_1fr] lg:gap-16">

		<!-- Gallery ------------------------------------------------------- -->
		<div class="lg:sticky lg:top-32 lg:self-start">
			<div class="agz-gallery border-2 border-ink bg-paper p-3">
				<?php
				/**
				 * Hook: woocommerce_before_single_product_summary.
				 * Renders the sale flash and the product gallery.
				 */
				do_action( 'woocommerce_before_single_product_summary' );
				?>
			</div>

			<p class="mt-3 font-mono text-[10px] uppercase tracking-label text-ink/45">
				<?php esc_html_e( 'Photographs show a representative unit. Pack sizes vary by variant.', 'shop-agroznet' ); ?>
			</p>
		</div>

		<!-- Summary ------------------------------------------------------- -->
		<div class="summary entry-summary">

			<div class="flex items-center justify-between gap-4 font-mono text-[11px] uppercase tracking-label text-ink/55">
				<span><?php echo wp_kses_post( wc_get_product_category_list( $product->get_id(), ' / ' ) ); ?></span>
				<span class="shrink-0 border-2 border-ink px-2 py-1 text-ink"><?php echo esc_html( agz_plot_code( $product->get_id() ) ); ?></span>
			</div>

			<h1 class="mt-4 font-display text-3xl font-extrabold uppercase leading-[0.98] tracking-stencil sm:text-5xl">
				<?php the_title(); ?>
			</h1>

			<!-- Price block -->
			<div class="mt-6 flex flex-wrap items-baseline gap-x-5 gap-y-2 border-y-2 border-ink py-5">
				<span class="agz-price font-mono text-3xl font-semibold text-ink">
					<?php echo wp_kses_post( $product->get_price_html() ); ?>
				</span>
				<?php if ( $agz_stock['label'] ) : ?>
					<span class="inline-flex items-center gap-2 font-mono text-[11px] uppercase tracking-label <?php echo esc_attr( $agz_stock['tone'] ); ?>">
						<span class="h-2 w-2 <?php echo $product->is_in_stock() ? 'bg-field' : 'bg-clay'; ?>"></span>
						<?php echo esc_html( $agz_stock['label'] ); ?>
					</span>
				<?php endif; ?>
				<?php if ( wc_tax_enabled() ) : ?>
					<span class="font-mono text-[10px] uppercase tracking-label text-ink/45"><?php esc_html_e( 'VAT included', 'shop-agroznet' ); ?></span>
				<?php endif; ?>
			</div>

			<?php if ( $product->get_short_description() ) : ?>
				<div class="agz-prose mt-6 text-base leading-relaxed text-ink/75">
					<?php echo wp_kses_post( wpautop( $product->get_short_description() ) ); ?>
				</div>
			<?php endif; ?>

			<div class="agz-summary-hooks mt-8">
				<?php
				/**
				 * Hook: woocommerce_single_product_summary.
				 * Rating, add-to-cart form, product meta and sharing.
				 */
				do_action( 'woocommerce_single_product_summary' );
				?>
			</div>

			<!-- Depot facts: pulled from real product data, not decoration -->
			<dl class="mt-10 divide-y divide-stone border-y-2 border-ink text-sm">
				<?php if ( $product->get_weight() ) : ?>
					<div class="flex items-baseline justify-between gap-6 py-3">
						<dt class="font-mono text-[11px] uppercase tracking-label text-ink/55"><?php esc_html_e( 'Unit weight', 'shop-agroznet' ); ?></dt>
						<dd class="font-mono"><?php echo esc_html( wc_format_weight( $product->get_weight() ) ); ?></dd>
					</div>
				<?php endif; ?>
				<?php if ( $product->has_dimensions() ) : ?>
					<div class="flex items-baseline justify-between gap-6 py-3">
						<dt class="font-mono text-[11px] uppercase tracking-label text-ink/55"><?php esc_html_e( 'Dimensions', 'shop-agroznet' ); ?></dt>
						<dd class="font-mono"><?php echo esc_html( wc_format_dimensions( $product->get_dimensions( false ) ) ); ?></dd>
					</div>
				<?php endif; ?>
				<div class="flex items-baseline justify-between gap-6 py-3">
					<dt class="font-mono text-[11px] uppercase tracking-label text-ink/55"><?php esc_html_e( 'Dispatch', 'shop-agroznet' ); ?></dt>
					<dd class="text-right text-ink/75"><?php esc_html_e( 'Same working day before 14:00', 'shop-agroznet' ); ?></dd>
				</div>
				<div class="flex items-baseline justify-between gap-6 py-3">
					<dt class="font-mono text-[11px] uppercase tracking-label text-ink/55"><?php esc_html_e( 'Bulk quantities', 'shop-agroznet' ); ?></dt>
					<dd class="text-right text-ink/75"><?php esc_html_e( 'Quoted per farm — call the depot', 'shop-agroznet' ); ?></dd>
				</div>
			</dl>
		</div>
	</div>

	<!-- Attributes strip: only when the product actually carries attributes -->
	<?php if ( ! empty( $agz_attrs ) ) : ?>
		<section class="mt-20">
			<?php agz_row_marker( __( 'Specification', 'shop-agroznet' ) ); ?>
			<div class="mt-6 grid gap-px border-2 border-ink bg-ink sm:grid-cols-2 lg:grid-cols-3">
				<?php foreach ( $agz_attrs as $agz_attr ) : ?>
					<?php
					if ( ! $agz_attr->get_visible() ) {
						continue;
					}
					$agz_values = $agz_attr->is_taxonomy()
						? wc_get_product_terms( $product->get_id(), $agz_attr->get_name(), array( 'fields' => 'names' ) )
						: $agz_attr->get_options();
					?>
					<div class="bg-limewash px-5 py-4">
						<p class="font-mono text-[10px] uppercase tracking-label text-ink/50"><?php echo esc_html( wc_attribute_label( $agz_attr->get_name() ) ); ?></p>
						<p class="mt-1.5 text-sm text-ink"><?php echo esc_html( implode( ', ', (array) $agz_values ) ); ?></p>
					</div>
				<?php endforeach; ?>
			</div>
		</section>
	<?php endif; ?>

	<!-- Tabs, upsells and related products stay on plugin defaults -->
	<div class="agz-after-summary mt-20">
		<?php
		/**
		 * Hook: woocommerce_after_single_product_summary.
		 */
		do_action( 'woocommerce_after_single_product_summary' );
		?>
	</div>
</div>

<?php do_action( 'woocommerce_after_single_product' ); ?>
