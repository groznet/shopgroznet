<?php
/**
 * Cart page.
 *
 * Override of woocommerce/templates/cart/cart.php. The default table is
 * replaced by a row list so it reads the same on a phone in a yard as on a
 * desktop. All form names, nonces and hooks are preserved.
 *
 * @package ShopAgroznet
 * @version 7.9.0
 */

defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_before_cart' );
?>

<div class="agz-cart">

	<header class="border-b-2 border-ink pb-8">
		<?php agz_breadcrumb(); ?>
		<h1 class="mt-5 font-display text-4xl font-extrabold uppercase leading-[0.95] tracking-stencil sm:text-6xl">
			<?php esc_html_e( 'Your order', 'shop-agroznet' ); ?>
		</h1>
		<p class="mt-4 font-mono text-[11px] uppercase tracking-label text-ink/55">
			<?php
			printf(
				/* translators: %d: number of items. */
				esc_html( _n( '%d line in the order', '%d lines in the order', WC()->cart->get_cart_contents_count(), 'shop-agroznet' ) ),
				(int) WC()->cart->get_cart_contents_count()
			);
			?>
		</p>
	</header>

	<div class="mt-10 grid gap-10 lg:grid-cols-[1fr_22rem] lg:gap-14 lg:items-start">

		<!-- Lines --------------------------------------------------------- -->
		<form class="woocommerce-cart-form" action="<?php echo esc_url( wc_get_cart_url() ); ?>" method="post">
			<?php do_action( 'woocommerce_before_cart_table' ); ?>

			<div class="woocommerce-cart-form__contents border-t-2 border-ink">
				<?php do_action( 'woocommerce_before_cart_contents' ); ?>

				<?php
				foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
					$_product     = apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key );
					$product_id   = apply_filters( 'woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key );
					$product_permalink = apply_filters( 'woocommerce_cart_item_permalink', $_product->is_visible() ? $_product->get_permalink( $cart_item ) : '', $cart_item, $cart_item_key );

					if ( ! $_product || ! $_product->exists() || $cart_item['quantity'] <= 0 || ! apply_filters( 'woocommerce_cart_item_visible', true, $cart_item, $cart_item_key ) ) {
						continue;
					}

					$product_name = apply_filters( 'woocommerce_cart_item_name', $_product->get_name(), $cart_item, $cart_item_key );
					?>
					<div class="woocommerce-cart-form__cart-item <?php echo esc_attr( apply_filters( 'woocommerce_cart_item_class', 'cart_item', $cart_item, $cart_item_key ) ); ?> grid grid-cols-[5rem_1fr] gap-4 border-b-2 border-stone py-6 sm:grid-cols-[6rem_1fr_auto] sm:gap-6">

						<!-- Thumbnail -->
						<div class="row-span-2 sm:row-span-1">
							<?php
							$thumbnail = apply_filters( 'woocommerce_cart_item_thumbnail', $_product->get_image( 'woocommerce_thumbnail', array( 'class' => 'h-full w-full object-cover' ) ), $cart_item, $cart_item_key );

							if ( ! $product_permalink ) {
								echo '<span class="block aspect-square overflow-hidden border-2 border-ink bg-paper">' . wp_kses_post( $thumbnail ) . '</span>';
							} else {
								printf( '<a href="%s" class="block aspect-square overflow-hidden border-2 border-ink bg-paper" tabindex="-1" aria-hidden="true">%s</a>', esc_url( $product_permalink ), wp_kses_post( $thumbnail ) );
							}
							?>
						</div>

						<!-- Description -->
						<div class="min-w-0">
							<p class="font-mono text-[10px] uppercase tracking-label text-ink/50"><?php echo esc_html( agz_plot_code( $product_id ) ); ?></p>

							<h2 class="mt-1 font-display text-base font-bold uppercase leading-tight tracking-[0.02em]">
								<?php
								if ( ! $product_permalink ) {
									echo wp_kses_post( $product_name );
								} else {
									printf( '<a href="%s" class="hover:text-field">%s</a>', esc_url( $product_permalink ), wp_kses_post( $product_name ) );
								}
								?>
							</h2>

							<?php
							do_action( 'woocommerce_after_cart_item_name', $cart_item, $cart_item_key );

							// Variation and add-on meta.
							echo wc_get_formatted_cart_item_data( $cart_item ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

							if ( $_product->backorders_require_notification() && $_product->is_on_backorder( $cart_item['quantity'] ) ) {
								echo wp_kses_post( apply_filters( 'woocommerce_cart_item_backorder_notification', '<p class="backorder_notification mt-2 font-mono text-[10px] uppercase tracking-label text-clay">' . esc_html__( 'On backorder — ships when the next delivery lands', 'shop-agroznet' ) . '</p>', $product_id ) );
							}
							?>

							<p class="mt-2 font-mono text-sm text-ink/70">
								<?php
								echo apply_filters( 'woocommerce_cart_item_price', WC()->cart->get_product_price( $_product ), $cart_item, $cart_item_key ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
								echo ' <span class="text-ink/40">' . esc_html__( 'each', 'shop-agroznet' ) . '</span>';
								?>
							</p>

							<a href="<?php echo esc_url( wc_get_cart_remove_url( $cart_item_key ) ); ?>"
								class="mt-3 inline-block font-mono text-[10px] uppercase tracking-label text-clay underline underline-offset-4 hover:no-underline"
								aria-label="<?php echo esc_attr( sprintf( __( 'Remove %s from your order', 'shop-agroznet' ), wp_strip_all_tags( $product_name ) ) ); ?>"
								data-product_id="<?php echo esc_attr( $product_id ); ?>"
								data-product_sku="<?php echo esc_attr( $_product->get_sku() ); ?>">
								<?php esc_html_e( 'Remove line', 'shop-agroznet' ); ?>
							</a>
						</div>

						<!-- Quantity and line total -->
						<div class="col-start-2 flex items-center justify-between gap-6 sm:col-start-3 sm:flex-col sm:items-end sm:justify-start">
							<div class="agz-qty">
								<?php
								if ( $_product->is_sold_individually() ) {
									$min_quantity = 1;
									$max_quantity = 1;
								} else {
									$min_quantity = 0;
									$max_quantity = $_product->get_max_purchase_quantity();
								}

								$product_quantity = woocommerce_quantity_input(
									array(
										'input_name'   => "cart[{$cart_item_key}][qty]",
										'input_value'  => $cart_item['quantity'],
										'max_value'    => $max_quantity,
										'min_value'    => $min_quantity,
										'product_name' => $product_name,
									),
									$_product,
									false
								);

								echo apply_filters( 'woocommerce_cart_item_quantity', $product_quantity, $cart_item_key, $cart_item ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
								?>
							</div>

							<span class="font-mono text-lg font-semibold sm:mt-4">
								<?php
								echo apply_filters( 'woocommerce_cart_item_subtotal', WC()->cart->get_product_subtotal( $_product, $cart_item['quantity'] ), $cart_item, $cart_item_key ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
								?>
							</span>
						</div>
					</div>
					<?php
				}
				?>

				<?php do_action( 'woocommerce_cart_contents' ); ?>

				<!-- Actions -->
				<div class="flex flex-col gap-4 py-6 sm:flex-row sm:items-center sm:justify-between">
					<?php if ( wc_coupons_enabled() ) : ?>
						<div class="coupon flex w-full max-w-sm gap-2">
							<label for="coupon_code" class="sr-only"><?php esc_html_e( 'Trade code', 'shop-agroznet' ); ?></label>
							<input type="text" name="coupon_code" class="input-text w-full border-2 border-ink bg-paper px-4 py-3 font-mono text-sm uppercase tracking-label placeholder:text-ink/35 focus:outline-none focus:ring-2 focus:ring-field focus:ring-offset-2" id="coupon_code" value="" placeholder="<?php esc_attr_e( 'Trade code', 'shop-agroznet' ); ?>">
							<button type="submit" class="<?php echo esc_attr( agz_btn( 'outline' ) ); ?> shrink-0" name="apply_coupon" value="<?php esc_attr_e( 'Apply', 'shop-agroznet' ); ?>"><?php esc_html_e( 'Apply', 'shop-agroznet' ); ?></button>
							<?php do_action( 'woocommerce_cart_coupon' ); ?>
						</div>
					<?php endif; ?>

					<button type="submit" class="<?php echo esc_attr( agz_btn( 'outline' ) ); ?>" name="update_cart" value="<?php esc_attr_e( 'Update order', 'shop-agroznet' ); ?>">
						<?php esc_html_e( 'Update order', 'shop-agroznet' ); ?>
					</button>

					<?php do_action( 'woocommerce_cart_actions' ); ?>
					<?php wp_nonce_field( 'woocommerce-cart', 'woocommerce-cart-nonce' ); ?>
				</div>

				<?php do_action( 'woocommerce_after_cart_contents' ); ?>
			</div>

			<?php do_action( 'woocommerce_after_cart_table' ); ?>
		</form>

		<!-- Totals -------------------------------------------------------- -->
		<aside class="cart-collaterals lg:sticky lg:top-32">
			<?php do_action( 'woocommerce_before_cart_collaterals' ); ?>

			<div class="border-2 border-ink bg-paper p-6 shadow-tag">
				<?php agz_row_marker( __( 'Summary', 'shop-agroznet' ) ); ?>
				<div class="agz-totals mt-5">
					<?php
					/**
					 * Hook: woocommerce_cart_collaterals.
					 * Cart totals render here. Cross-sells are moved below the
					 * grid in inc/woocommerce.php so they get full width.
					 */
					do_action( 'woocommerce_cart_collaterals' );
					?>
				</div>
			</div>

			<p class="mt-4 font-mono text-[10px] uppercase leading-relaxed tracking-label text-ink/45">
				<?php esc_html_e( 'Delivery is calculated at checkout from your postcode. Pallet freight is quoted separately.', 'shop-agroznet' ); ?>
			</p>
		</aside>
	</div>

	<?php
	// Cross-sells, full width beneath the order.
	if ( function_exists( 'woocommerce_cross_sell_display' ) ) {
		echo '<section class="agz-cross-sells mt-20">';
		woocommerce_cross_sell_display( 3, 3 );
		echo '</section>';
	}
	?>
</div>

<?php do_action( 'woocommerce_after_cart' ); ?>
