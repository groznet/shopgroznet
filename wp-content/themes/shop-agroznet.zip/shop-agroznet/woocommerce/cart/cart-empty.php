<?php
/**
 * Empty cart.
 *
 * Override of woocommerce/templates/cart/cart-empty.php. Part of the cart
 * override — an empty screen is an invitation to act, not an apology.
 *
 * @package ShopAgroznet
 * @version 7.0.1
 */

defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_before_cart' );
?>

<div class="agz-cart-empty">
	<header class="border-b-2 border-ink pb-8">
		<?php agz_breadcrumb(); ?>
		<h1 class="mt-5 font-display text-4xl font-extrabold uppercase leading-[0.95] tracking-stencil sm:text-6xl">
			<?php esc_html_e( 'Your order', 'shop-agroznet' ); ?>
		</h1>
	</header>

	<div class="mt-10 border-2 border-ink bg-paper p-10 sm:p-16">
		<p class="font-mono text-[11px] uppercase tracking-label text-ink/50"><?php esc_html_e( 'Empty', 'shop-agroznet' ); ?></p>
		<h2 class="mt-4 max-w-xl font-display text-2xl font-extrabold uppercase leading-tight tracking-stencil sm:text-4xl">
			<?php esc_html_e( 'Nothing loaded yet', 'shop-agroznet' ); ?>
		</h2>
		<p class="mt-4 max-w-md text-sm leading-relaxed text-ink/70">
			<?php esc_html_e( 'Add seed, feed, chemistry or parts from the catalogue and they will collect here. Lines are held for 30 days.', 'shop-agroznet' ); ?>
		</p>

		<div class="mt-8 flex flex-wrap gap-3">
			<a href="<?php echo esc_url( apply_filters( 'woocommerce_return_to_shop_redirect', wc_get_page_permalink( 'shop' ) ) ); ?>" class="<?php echo esc_attr( agz_btn( 'solid' ) ); ?>">
				<?php esc_html_e( 'Browse the depot', 'shop-agroznet' ); ?>
			</a>
			<a href="<?php echo esc_url( wc_get_page_permalink( 'myaccount' ) ); ?>" class="<?php echo esc_attr( agz_btn( 'outline' ) ); ?>">
				<?php esc_html_e( 'Reorder from history', 'shop-agroznet' ); ?>
			</a>
		</div>

		<?php
		/**
		 * Hook: woocommerce_cart_is_empty — kept so plugins can add their own
		 * messaging (the default "return to shop" button is unhooked).
		 */
		do_action( 'woocommerce_cart_is_empty' );
		?>
	</div>
</div>
