<?php
/**
 * Site footer. Shared by every template, WooCommerce included.
 *
 * @package ShopAgroznet
 */

defined( 'ABSPATH' ) || exit;
?>

	<footer id="colophon" class="mt-auto border-t-2 border-ink bg-ink text-limewash">

		<!-- Depot promises -->
		<div class="border-b border-limewash/15">
			<div class="mx-auto grid max-w-shell gap-px bg-limewash/15 px-4 sm:px-6 lg:grid-cols-3 lg:px-8">
				<?php
				$agz_promises = array(
					array(
						'code'  => 'D-01',
						'title' => __( 'Same-day dispatch', 'shop-agroznet' ),
						'body'  => __( 'Order before 14:00 on a working day and it leaves the depot that afternoon.', 'shop-agroznet' ),
					),
					array(
						'code'  => 'D-02',
						'title' => __( 'Agronomist on the line', 'shop-agroznet' ),
						'body'  => __( 'Unsure which variety or rate suits your ground? Call before you buy.', 'shop-agroznet' ),
					),
					array(
						'code'  => 'D-03',
						'title' => __( 'Bulk pricing on request', 'shop-agroznet' ),
						'body'  => __( 'Pallet and tonne quantities are quoted per farm. Ask for a trade account.', 'shop-agroznet' ),
					),
				);
				foreach ( $agz_promises as $agz_promise ) :
					?>
					<div class="bg-ink px-2 py-8 lg:px-8">
						<p class="font-mono text-[11px] uppercase tracking-label text-tractor"><?php echo esc_html( $agz_promise['code'] ); ?></p>
						<h3 class="mt-3 font-display text-lg font-bold uppercase tracking-stencil"><?php echo esc_html( $agz_promise['title'] ); ?></h3>
						<p class="mt-2 max-w-sm text-sm leading-relaxed text-limewash/70"><?php echo esc_html( $agz_promise['body'] ); ?></p>
					</div>
				<?php endforeach; ?>
			</div>
		</div>

		<!-- Columns -->
		<div class="mx-auto max-w-shell px-4 py-14 sm:px-6 lg:px-8">
			<div class="grid gap-12 lg:grid-cols-[1.2fr_repeat(3,1fr)]">

				<div>
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="flex items-center gap-3" rel="home">
						<span class="grid h-10 w-10 place-items-center border-2 border-limewash bg-tractor text-ink">
							<svg class="h-5 w-5" viewBox="0 0 24 24" fill="none" aria-hidden="true">
								<path d="M12 21V9" stroke="currentColor" stroke-width="2"/>
								<path d="M12 12c0-4 3-7 8-7 0 5-3 8-8 8Z" fill="currentColor"/>
								<path d="M12 16c0-3-2.2-5.5-6-5.5 0 3.8 2.4 6 6 6Z" fill="currentColor" opacity=".55"/>
							</svg>
						</span>
						<span class="font-display text-xl font-extrabold uppercase tracking-stencil"><?php bloginfo( 'name' ); ?></span>
					</a>
					<p class="mt-5 max-w-xs text-sm leading-relaxed text-limewash/70">
						<?php
						echo esc_html(
							get_theme_mod(
								'agz_footer_blurb',
								__( 'Seed, feed, crop protection and machinery parts, held in stock and sold by people who work the same ground you do.', 'shop-agroznet' )
							)
						);
						?>
					</p>

					<div class="mt-6 space-y-1 font-mono text-[11px] uppercase tracking-label text-limewash/60">
						<p><?php echo esc_html( get_theme_mod( 'agz_address', __( 'Depot 4, Industrial Road', 'shop-agroznet' ) ) ); ?></p>
						<p><?php echo esc_html( get_theme_mod( 'agz_hours', __( 'Mon–Fri 07:00–17:00 / Sat 08:00–13:00', 'shop-agroznet' ) ) ); ?></p>
					</div>
				</div>

				<?php for ( $agz_i = 1; $agz_i <= 3; $agz_i++ ) : ?>
					<div>
						<?php if ( is_active_sidebar( 'footer-' . $agz_i ) ) : ?>
							<?php dynamic_sidebar( 'footer-' . $agz_i ); ?>
						<?php elseif ( 1 === $agz_i && has_nav_menu( 'footer' ) ) : ?>
							<h2 class="font-mono text-[11px] uppercase tracking-label text-limewash/50"><?php esc_html_e( 'Shop', 'shop-agroznet' ); ?></h2>
							<?php
							wp_nav_menu(
								array(
									'theme_location' => 'footer',
									'container'      => false,
									'menu_class'     => 'mt-4 space-y-2.5 text-sm text-limewash/75 [&_a:hover]:text-tractor',
									'depth'          => 1,
								)
							);
							?>
						<?php elseif ( 2 === $agz_i && has_nav_menu( 'departments' ) ) : ?>
							<h2 class="font-mono text-[11px] uppercase tracking-label text-limewash/50"><?php esc_html_e( 'Departments', 'shop-agroznet' ); ?></h2>
							<?php
							wp_nav_menu(
								array(
									'theme_location' => 'departments',
									'container'      => false,
									'menu_class'     => 'mt-4 space-y-2.5 text-sm text-limewash/75 [&_a:hover]:text-tractor',
									'depth'          => 1,
								)
							);
							?>
						<?php elseif ( 3 === $agz_i ) : ?>
							<h2 class="font-mono text-[11px] uppercase tracking-label text-limewash/50"><?php esc_html_e( 'Reach the depot', 'shop-agroznet' ); ?></h2>
							<ul class="mt-4 space-y-2.5 text-sm text-limewash/75">
								<li><a class="hover:text-tractor" href="tel:<?php echo esc_attr( get_theme_mod( 'agz_phone_raw', '+38765000000' ) ); ?>"><?php echo esc_html( get_theme_mod( 'agz_phone', '+387 65 000 000' ) ); ?></a></li>
								<li><a class="hover:text-tractor" href="mailto:<?php echo esc_attr( get_theme_mod( 'agz_email', 'depot@example.com' ) ); ?>"><?php echo esc_html( get_theme_mod( 'agz_email', 'depot@example.com' ) ); ?></a></li>
								<?php if ( function_exists( 'wc_get_page_permalink' ) ) : ?>
									<li><a class="hover:text-tractor" href="<?php echo esc_url( wc_get_page_permalink( 'myaccount' ) ); ?>"><?php esc_html_e( 'Order history', 'shop-agroznet' ); ?></a></li>
								<?php endif; ?>
							</ul>
						<?php endif; ?>
					</div>
				<?php endfor; ?>
			</div>
		</div>

		<!-- Baseline -->
		<div class="border-t border-limewash/15">
			<div class="mx-auto flex max-w-shell flex-col gap-4 px-4 py-6 font-mono text-[11px] uppercase tracking-label text-limewash/50 sm:flex-row sm:items-center sm:justify-between sm:px-6 lg:px-8">
				<p>
					<?php
					printf(
						/* translators: 1: year, 2: site name. */
						esc_html__( '© %1$s %2$s. All rights reserved.', 'shop-agroznet' ),
						esc_html( gmdate( 'Y' ) ),
						esc_html( get_bloginfo( 'name' ) )
					);
					?>
				</p>
				<?php if ( has_nav_menu( 'legal' ) ) : ?>
					<?php
					wp_nav_menu(
						array(
							'theme_location' => 'legal',
							'container'      => false,
							'menu_class'     => 'flex flex-wrap gap-x-6 gap-y-2 [&_a:hover]:text-tractor',
							'depth'          => 1,
						)
					);
					?>
				<?php endif; ?>
			</div>
		</div>
	</footer>
</div><!-- #page -->

<?php wp_footer(); ?>
</body>
</html>
