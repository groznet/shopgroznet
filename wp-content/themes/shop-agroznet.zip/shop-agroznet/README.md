# Shop Agroznet

A classic PHP WooCommerce theme for an agricultural supply shop. Tailwind CSS
for styling, Alpine.js for interactivity, hand-written CSS and JS only where
WooCommerce output leaves no template to add classes to.

Install at `wp-content/themes/shop-agroznet`.

---

## Why classic PHP templates

WooCommerce's template system is PHP: overrides live in a `woocommerce/` folder
inside the theme and are resolved by `wc_get_template()`. A block theme would
mean going through WooCommerce Blocks and `templates/*.html`, which cannot host
Tailwind class names or Alpine attributes with the same directness.

So the theme is classic, and picks up the modern conventions that still apply:

- `theme.json` publishes the palette, the three typefaces and the type scale to
  the block editor, so editor content matches the front end.
- `add_theme_support( 'editor-styles' )`, `align-wide` and `responsive-embeds`
  are on, and `assets/css/theme.css` is loaded in the editor.
- A selectable page template (`page-templates/shopfront.php`) rather than a
  hardcoded `front-page.php`, so the front page stays the editor's choice.

## Design language

| Token | Value | Used for |
| --- | --- | --- |
| `ink` | `#16261C` | Text, every border, the footer |
| `field` | `#1F6F43` | Primary actions, in-stock state |
| `tractor` | `#F2C230` | Accent — badges, the punched tag hole, hover |
| `clay` | `#B4532A` | Low stock, errors, destructive links |
| `limewash` | `#F1F3EC` | Page background |
| `paper` | `#FBFCF8` | Raised surfaces |

Typefaces: **Archivo** (display, uppercase, tight tracking), **Public Sans**
(body), **IBM Plex Mono** (prices, SKUs, labels, counts).

The recurring device is the **field tag**: products are presented like
agronomy trial-plot labels — a mono eyebrow carrying category and plot code, a
2px hard border, a punched hang-tag hole, and a hard offset shadow rather than a
blur. Section headings sit on a ticked "row marker" rule.

Palette and type live in **one place** — `agz_design_tokens()` in
`inc/assets.php` — and are mirrored into `tailwind.config.js` for the compiled
build and into CSS custom properties for `theme.css`.

## Tailwind: two ways to run

**No build step (works immediately).** If `assets/css/tailwind.build.css` is
absent, the theme loads the Tailwind browser runtime and injects the token
config. Nothing to install. Fine for staging; it compiles in the browser.

**Compiled (use in production).**

```bash
cd wp-content/themes/shop-agroznet
npm install
npm run build     # or: npm run dev  (watch)
```

That writes `assets/css/tailwind.build.css`, which the theme detects and uses
instead of the runtime. Cache-busted by file modification time.

Alpine.js and its focus plugin load from jsDelivr, deferred. To self-host,
drop the files in `assets/js/` and change the two `wp_enqueue_script` calls in
`inc/assets.php`.

## WooCommerce overrides

Copied from `woocommerce/templates/`, same relative paths and file names:

```
woocommerce/
├── archive-product.php          shop, category, tag and product search
├── content-product.php          the product card in the loop
├── single-product.php           single product shell
├── content-single-product.php   single product layout
├── cart/
│   ├── cart.php                 cart
│   └── cart-empty.php           empty cart
└── checkout/
    └── form-checkout.php        checkout
```

Everything else — my account, order confirmation, emails, mini-cart, tabs,
related products, notices, form fields — stays on plugin defaults and is styled
through hooks in `inc/woocommerce.php` and CSS in `assets/css/theme.css`.

`content-product.php` and `content-single-product.php` are included because
they *are* the shop archive and the single product page; the parent files are
only wrappers around a `wc_get_template_part()` call. Overriding one without
the other would leave default WooCommerce markup in the middle of the page.

**Keeping the overrides current.** Each file carries a `@version` matching the
WooCommerce template it was copied from. When WooCommerce reports an outdated
template under *WooCommerce → Status*, diff the plugin's file against ours and
port the change.

Every override keeps its `do_action()` calls, form field names, nonces and
`apply_filters()` wrappers, so extensions that hook them keep working. Where a
template renders something itself (the product title, the price, the archive
toolbar), the *default callback* is removed in `inc/woocommerce.php` and the
hook still fires — the removals are listed together with a comment each.

## Shared header and footer

`header.php` and `footer.php` are used by every page, WooCommerce included.
WooCommerce's own `woocommerce_output_content_wrapper` is unhooked and replaced
with the theme's `<main>` shell, so pages that are *not* overridden (my account,
order received) sit inside the same container, header and footer as everything
else.

## Menus, widgets, options

Menus: `primary`, `departments` (the strip under the masthead), `footer`,
`legal`.
Widget areas: `shop-sidebar` (renders the filter rail on the shop archive when
it has widgets — leave it empty and the grid goes full width), `footer-1..3`.
Customizer text: `agz_notice`, `agz_phone`, `agz_phone_raw`, `agz_address`,
`agz_hours`, `agz_footer_blurb` — all have sensible defaults.

## Interactivity

Alpine handles the mobile drawer, the search panel, dropdown menus, the slide-
over order drawer, and the grid/list toggle. `assets/js/theme.js` covers what
attributes cannot: quantity steppers injected into WooCommerce's `.quantity`
markup, sort-on-change, re-binding after AJAX fragment refreshes, and opening
the drawer on `added_to_cart`. Without JavaScript everything still works —
sorting has a submit button, quantities type, the cart updates on submit.

## Accessibility

Skip link, visible focus rings on every interactive element, `aria-expanded` on
disclosures, focus trapping in the drawers via `@alpinejs/focus`, and
`prefers-reduced-motion` honoured for the card lift and button press.

## Before launch

1. Add `screenshot.png` (1200×900) if you want a custom preview thumbnail.
2. Run `npm run build` and deploy the compiled CSS.
3. Self-host Alpine and the Google Fonts if you need to avoid third-party
   requests.
4. Set the Shopfront page template on your front page.
