<?php
/**
 * Single post.
 *
 * @package ShopAgroznet
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>

<main id="main" class="mx-auto w-full max-w-3xl px-4 pb-24 pt-10 sm:px-6">
	<?php
	while ( have_posts() ) :
		the_post();
		?>
		<article <?php post_class(); ?>>
			<header class="mb-8">
				<?php agz_breadcrumb(); ?>
				<h1 class="mt-5 font-display text-3xl font-extrabold uppercase leading-[0.98] tracking-stencil sm:text-5xl"><?php the_title(); ?></h1>
				<div class="mt-5"><?php agz_post_meta(); ?></div>
			</header>

			<?php if ( has_post_thumbnail() ) : ?>
				<figure class="mb-10 border-2 border-ink bg-paper">
					<?php the_post_thumbnail( 'large', array( 'class' => 'w-full object-cover' ) ); ?>
				</figure>
			<?php endif; ?>

			<div class="agz-prose">
				<?php
				the_content();
				wp_link_pages(
					array(
						'before' => '<div class="mt-8 font-mono text-xs uppercase tracking-label">',
						'after'  => '</div>',
					)
				);
				?>
			</div>

			<footer class="mt-12 border-t-2 border-ink pt-6">
				<?php the_tags( '<div class="flex flex-wrap gap-2 font-mono text-[11px] uppercase tracking-label text-ink/60">', '', '</div>' ); ?>
			</footer>
		</article>

		<?php
		if ( comments_open() || get_comments_number() ) {
			echo '<div class="agz-comments mt-14">';
			comments_template();
			echo '</div>';
		}

	endwhile;
	?>
</main>

<?php
get_footer();
