/**
 * Shop Agroznet — behaviour that Alpine attributes alone cannot cover.
 *
 * Everything here is progressive: without JS the shop still sorts (via the
 * noscript submit button), quantities still type, and the cart still updates.
 */
( function () {
	'use strict';

	var VIEW_KEY = 'agz-archive-view';

	/**
	 * Alpine component for the shop archive.
	 * Registered as a global so `x-data="agzArchive()"` resolves whether Alpine
	 * boots before or after this file.
	 */
	window.agzArchive = function () {
		var stored = 'grid';

		try {
			stored = window.localStorage.getItem( VIEW_KEY ) || 'grid';
		} catch ( e ) {
			stored = 'grid';
		}

		return {
			view: stored,
			filters: false,
			setView: function ( next ) {
				this.view = next;
				try {
					window.localStorage.setItem( VIEW_KEY, next );
				} catch ( e ) {
					/* Storage unavailable — the choice just won't persist. */
				}
			}
		};
	};

	/**
	 * Sorting select submits its own form on change.
	 */
	function bindOrdering() {
		document.querySelectorAll( '.agz-ordering select[name="orderby"]' ).forEach( function ( select ) {
			select.addEventListener( 'change', function () {
				var form = select.closest( 'form' );
				if ( form ) {
					form.submit();
				}
			} );
		} );
	}

	/**
	 * Wrap every WooCommerce quantity field with minus/plus controls.
	 * WooCommerce renders `.quantity > input.qty`; the buttons are injected so
	 * the cart and single product forms behave the same.
	 */
	function buildSteppers( scope ) {
		( scope || document ).querySelectorAll( '.quantity' ).forEach( function ( wrap ) {
			if ( wrap.dataset.agzStepper === 'done' ) {
				return;
			}

			var input = wrap.querySelector( 'input.qty' );

			if ( ! input || input.type === 'hidden' ) {
				return;
			}

			wrap.dataset.agzStepper = 'done';

			var minus = document.createElement( 'button' );
			var plus = document.createElement( 'button' );

			minus.type = plus.type = 'button';
			minus.className = plus.className = 'agz-qty-step';
			minus.textContent = '\u2212';
			plus.textContent = '+';
			minus.setAttribute( 'aria-label', 'Decrease quantity' );
			plus.setAttribute( 'aria-label', 'Increase quantity' );

			function step( direction ) {
				var current = parseFloat( input.value ) || 0;
				var stepBy = parseFloat( input.getAttribute( 'step' ) ) || 1;
				var min = parseFloat( input.getAttribute( 'min' ) );
				var max = parseFloat( input.getAttribute( 'max' ) );
				var next = current + direction * stepBy;

				if ( ! isNaN( min ) && next < min ) {
					next = min;
				}

				if ( ! isNaN( max ) && max > 0 && next > max ) {
					next = max;
				}

				if ( next !== current ) {
					input.value = next;
					input.dispatchEvent( new Event( 'change', { bubbles: true } ) );
				}
			}

			minus.addEventListener( 'click', function () {
				step( -1 );
			} );

			plus.addEventListener( 'click', function () {
				step( 1 );
			} );

			wrap.insertBefore( minus, input );
			wrap.appendChild( plus );
		} );
	}

	/**
	 * Changing a cart quantity enables the update button, so the change is
	 * never silently lost.
	 */
	function bindCartUpdate() {
		var form = document.querySelector( '.woocommerce-cart-form' );

		if ( ! form ) {
			return;
		}

		form.addEventListener( 'change', function ( event ) {
			if ( event.target.matches( 'input.qty' ) ) {
				var button = form.querySelector( '[name="update_cart"]' );
				if ( button ) {
					button.removeAttribute( 'disabled' );
					button.classList.add( 'agz-update-pending' );
				}
			}
		} );
	}

	/**
	 * Slide the order drawer open after an AJAX add to cart.
	 */
	function bindAddedToCart() {
		if ( ! window.jQuery ) {
			return;
		}

		window.jQuery( document.body ).on( 'added_to_cart', function () {
			window.dispatchEvent( new CustomEvent( 'open-cart' ) );
		} );

		// Fragments replace the drawer markup; re-attach steppers inside it.
		window.jQuery( document.body ).on( 'wc_fragments_refreshed wc_fragments_loaded updated_wc_div updated_cart_totals', function () {
			buildSteppers( document );
		} );
	}

	function init() {
		bindOrdering();
		buildSteppers( document );
		bindCartUpdate();
		bindAddedToCart();
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}
}() );
