<?php
/**
 * 404.
 *
 * @package ShopAgroznet
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>

<main id="main" class="mx-auto flex w-full max-w-2xl flex-col items-start px-4 pb-28 pt-20 sm:px-6">
	<p class="font-mono text-[11px] uppercase tracking-label text-clay"><?php esc_html_e( 'Error 404', 'shop-agroznet' ); ?></p>
	<h1 class="mt-4 font-display text-4xl font-extrabold uppercase leading-[0.95] tracking-stencil sm:text-6xl">
		<?php esc_html_e( 'This row is empty', 'shop-agroznet' ); ?>
	</h1>
	<p class="mt-5 max-w-md text-base text-ink/70">
		<?php esc_html_e( 'The page you asked for has moved or was never planted. Search the catalogue or head back to the depot.', 'shop-agroznet' ); ?>
	</p>

	<div class="mt-8 w-full max-w-md"><?php get_search_form(); ?></div>

	<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="<?php echo esc_attr( agz_btn( 'solid' ) ); ?> mt-8">
		<?php esc_html_e( 'Back to the front page', 'shop-agroznet' ); ?>
	</a>
</main>

<?php
get_footer();
