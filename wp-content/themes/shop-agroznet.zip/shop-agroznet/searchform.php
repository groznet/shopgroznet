<?php
/**
 * Search form.
 *
 * @package ShopAgroznet
 */

defined( 'ABSPATH' ) || exit;

$agz_id = 'agz-search-' . wp_rand( 100, 999 );
?>
<form role="search" method="get" class="flex gap-2" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<label class="sr-only" for="<?php echo esc_attr( $agz_id ); ?>"><?php esc_html_e( 'Search', 'shop-agroznet' ); ?></label>
	<input id="<?php echo esc_attr( $agz_id ); ?>" type="search" name="s" value="<?php echo esc_attr( get_search_query() ); ?>"
		placeholder="<?php esc_attr_e( 'Search the catalogue…', 'shop-agroznet' ); ?>"
		class="w-full border-2 border-ink bg-paper px-4 py-3 font-body text-sm placeholder:text-ink/40 focus:outline-none focus:ring-2 focus:ring-field focus:ring-offset-2">
	<button type="submit" class="<?php echo esc_attr( agz_btn( 'accent' ) ); ?>"><?php esc_html_e( 'Go', 'shop-agroznet' ); ?></button>
</form>
