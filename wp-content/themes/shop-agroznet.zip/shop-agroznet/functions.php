<?php
/**
 * Shop Agroznet — theme bootstrap.
 *
 * @package ShopAgroznet
 */

defined( 'ABSPATH' ) || exit;

define( 'AGZ_VERSION', '1.0.0' );
define( 'AGZ_DIR', get_template_directory() );
define( 'AGZ_URI', get_template_directory_uri() );

require_once AGZ_DIR . '/inc/setup.php';
require_once AGZ_DIR . '/inc/assets.php';
require_once AGZ_DIR . '/inc/template-tags.php';
require_once AGZ_DIR . '/inc/nav-walker.php';

if ( class_exists( 'WooCommerce' ) ) {
	require_once AGZ_DIR . '/inc/woocommerce.php';
}
