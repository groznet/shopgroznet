<?php
/**
 * Static pages.
 *
 * WooCommerce cart, checkout and my-account are pages, so this template is the
 * shell they render inside. Shortcode-driven WooCommerce pages get a wider
 * container and no page title, because those templates supply their own.
 *
 * @package ShopAgroznet
 */

defined( 'ABSPATH' ) || exit;

get_header();

$agz_is_wc_page = function_exists( 'is_cart' ) && ( is_cart() || is_checkout() || is_account_page() );
$agz_width      = $agz_is_wc_page ? 'max-w-shell' : 'max-w-3xl';
?>

<main id="main" class="mx-auto w-full <?php echo esc_attr( $agz_width ); ?> px-4 pb-24 pt-10 sm:px-6 lg:px-8">
	<?php
	while ( have_posts() ) :
		the_post();
		?>
		<article <?php post_class(); ?>>
			<?php if ( ! $agz_is_wc_page ) : ?>
				<header class="mb-10">
					<?php agz_breadcrumb(); ?>
					<h1 class="mt-5 font-display text-3xl font-extrabold uppercase leading-[0.98] tracking-stencil sm:text-5xl"><?php the_title(); ?></h1>
				</header>
			<?php endif; ?>

			<div class="<?php echo $agz_is_wc_page ? '' : 'agz-prose'; ?>">
				<?php the_content(); ?>
			</div>
		</article>
		<?php
	endwhile;
	?>
</main>

<?php
get_footer();
